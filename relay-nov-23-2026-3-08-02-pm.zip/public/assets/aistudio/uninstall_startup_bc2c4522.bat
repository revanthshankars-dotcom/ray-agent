@echo off
title J.A.R.V.I.S. 2.0 — Remove Windows Auto-Startup
cd /d "%~dp0"

echo Removing J.A.R.V.I.S. from Windows Startup...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
    "$startupFolder = [Environment]::GetFolderPath('Startup'); " ^
    "$shortcutPath = Join-Path $startupFolder 'JARVIS_Assistant.lnk'; " ^
    "if (Test-Path $shortcutPath) { Remove-Item $shortcutPath -Force; Write-Host '[✓] Auto-Startup shortcut removed.' } else { Write-Host '[!] Shortcut was not present in Startup folder.' }"

echo.
pause
