#!/usr/bin/env python3
"""Quick verification of SystemMonitor imports and basic functionality."""

import sys
import os

# Add workspace to path
sys.path.insert(0, "c:\\Users\\AMBIKA\\Desktop\\jarvis-assistant")

try:
    print("[1] Testing imports...")
    from core.system_monitor import (
        SystemMonitor, 
        SystemMetrics, 
        ResourceHogAlert, 
        BatteryAnalysis,
        _metrics_to_json,
        _alert_to_json
    )
    print("✓ Imports successful\n")
    
    print("[2] Testing SystemMonitor initialization...")
    monitor = SystemMonitor(check_interval=2.0)
    print("✓ SystemMonitor initialized\n")
    
    print("[3] Testing get_current_metrics()...")
    metrics = monitor.get_current_metrics()
    print(f"✓ Metrics captured:")
    print(f"  CPU: {metrics.cpu_percent:.1f}%")
    print(f"  Memory: {metrics.memory_percent:.1f}%")
    print(f"  Processes: {metrics.process_count}")
    print(f"  Boot time: {metrics.boot_time}\n")
    
    print("[4] Testing analyze_resource_hogs()...")
    hogs = monitor.analyze_resource_hogs()
    print(f"✓ Resource hog analysis completed: {len(hogs)} hogs detected\n")
    
    print("[5] Testing get_battery_status()...")
    battery = monitor.get_battery_status()
    print(f"✓ Battery analysis completed:")
    print(f"  Current: {battery.current_percent:.1f}%")
    print(f"  Plugged in: {battery.plugged_in}")
    print(f"  Health: {battery.health_status}\n")
    
    print("[6] Testing start_monitoring()...")
    monitor.start_monitoring()
    import time
    time.sleep(2)
    print(f"✓ Monitor started, running={monitor.running}\n")
    
    print("[7] Testing stop_monitoring()...")
    monitor.stop_monitoring()
    print(f"✓ Monitor stopped, running={monitor.running}\n")
    
    print("[8] Testing JSON serialization...")
    json_metrics = _metrics_to_json(metrics)
    print(f"✓ JSON serialization works ({len(json_metrics)} bytes)\n")
    
    print("=" * 60)
    print("✓ ALL VERIFICATION TESTS PASSED")
    print("=" * 60)
    
except Exception as e:
    print(f"\n✗ ERROR: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)
