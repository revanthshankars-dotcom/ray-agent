"""
J.A.R.V.I.S. 2.0 - System Tray Application

Dual-Mode Execution Strategy:
  
  1. FastAPI Dashboard Mode (Default):
     - `python tray.py` launches FastAPI server on localhost:8000
     - Browser dashboard shows real-time system stats, controls, logs
     - REST API endpoints for third-party integrations
     - Lightweight web UI for monitoring and manual task triggering
     - Right-click tray icon for quick access to dashboard, docs, health check
  
  2. Daemon Mode (Background Services):
     - `python main.py --daemon` launches background monitoring
     - SystemMonitor: Continuously tracks CPU, memory, battery
     - AudioListener: Listens for wake words and voice commands
     - No browser UI; everything runs silently in system tray
     - Suitable for always-on autonomous operation
  
Both modes coexist in the enhanced tray system:
  - FastAPI server can detect if daemon services are running and show status
  - Daemon mode can be controlled from tray UI (pause/resume/stop)
  - They communicate via shared task_executor.py interrupt mechanism
  - Tray.py can spawn new daemon instances or connect to existing ones
"""
import sys
import os
import time
import threading
import webbrowser
import subprocess
from pathlib import Path

import pystray
from PIL import Image, ImageDraw
import uvicorn

# ── Path bootstrap so imports resolve ──────────────────────────────────────────
BASE_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE_DIR))

from core.task_executor import set_interrupt, clear_interrupt, is_interrupted

# ── Tray icon configuration ────────────────────────────────────────────────────
HOST = "0.0.0.0"
PORT = 8000
API_BASE = f"http://127.0.0.1:{PORT}"
DASHBOARD_URL = f"{API_BASE}/dashboard"

server_thread: threading.Thread | None = None
server_running = False


def create_icon_image(size: int = 64, color: tuple = (0, 120, 255)) -> Image.Image:
    """Generates a minimal J.A.R.V.I.S. arc-reactor style tray icon."""
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    # Outer ring
    draw.ellipse([2, 2, size - 2, size - 2], fill=color, outline=(255, 255, 255), width=2)

    # Inner core glow
    inner_margin = size // 5
    draw.ellipse(
        [inner_margin, inner_margin, size - inner_margin, size - inner_margin],
        fill=(255, 255, 255)
    )

    # Center dot
    c = size // 2
    r = size // 8
    draw.ellipse([c - r, c - r, c + r, c + r], fill=color)
    return img


def run_server():
    """Starts the FastAPI/uvicorn server in a daemon thread."""
    global server_running
    server_running = True
    try:
        uvicorn.run(
            "cloud_server.server:app",
            host=HOST,
            port=PORT,
            log_level="warning",
            reload=False,
        )
    except Exception as e:
        print(f"[Tray] Server error: {e}")
    finally:
        server_running = False


def start_server():
    """Launch server thread if not already running."""
    global server_thread
    if server_thread and server_thread.is_alive():
        return
    server_thread = threading.Thread(target=run_server, daemon=True, name="JarvisServer")
    server_thread.start()
    # Brief pause so the port can bind before browser opens
    time.sleep(1.5)


# ── Menu actions ───────────────────────────────────────────────────────────────

def open_dashboard(icon, item):
    webbrowser.open(DASHBOARD_URL)


def open_api_docs(icon, item):
    webbrowser.open(f"{API_BASE}/docs")


def open_health(icon, item):
    webbrowser.open(f"{API_BASE}/api/health")


def launch_desktop_assistant(icon, item):
    """Spawns the classic terminal assistant in a new console window."""
    python_exe = Path(sys.executable)
    subprocess.Popen(
        [str(python_exe), str(BASE_DIR / "main.py")],
        creationflags=subprocess.CREATE_NEW_CONSOLE
    )


def launch_daemon_mode(icon, item):
    """Spawns J.A.R.V.I.S. in daemon mode (background services)."""
    python_exe = Path(sys.executable)
    subprocess.Popen(
        [str(python_exe), str(BASE_DIR / "main.py"), "--daemon"],
        creationflags=subprocess.CREATE_NEW_CONSOLE
    )


def pause_execution(icon, item):
    """Pauses all running autonomous tasks via interrupt signal."""
    set_interrupt()
    print("[Tray] All running tasks paused.")


def resume_execution(icon, item):
    """Resumes execution after pause."""
    clear_interrupt()
    print("[Tray] Execution resumed.")


def trigger_clean_slate(icon, item):
    """Executes Protocol Clean Slate."""
    threading.Thread(target=lambda: __import__('core.protocols', fromlist=['execute_protocol']).execute_protocol('clean_slate'), daemon=True).start()


def trigger_house_party(icon, item):
    """Executes House Party Protocol."""
    threading.Thread(target=lambda: __import__('core.protocols', fromlist=['execute_protocol']).execute_protocol('house_party'), daemon=True).start()


def trigger_sentry_mode(icon, item):
    """Executes Sentry Mode."""
    threading.Thread(target=lambda: __import__('core.protocols', fromlist=['execute_protocol']).execute_protocol('sentry_mode'), daemon=True).start()


def trigger_veronica(icon, item):
    """Executes Protocol Veronica."""
    threading.Thread(target=lambda: __import__('core.protocols', fromlist=['execute_protocol']).execute_protocol('veronica'), daemon=True).start()


def on_quit(icon, item):
    set_interrupt()
    icon.stop()
    os._exit(0)


def build_menu(icon):
    return pystray.Menu(
        pystray.MenuItem("🌐  Open Dashboard", open_dashboard, default=True),
        pystray.MenuItem("📋  API Docs (Swagger)", open_api_docs),
        pystray.MenuItem("❤️   Health Check", open_health),
        pystray.Menu.SEPARATOR,
        pystray.MenuItem("🧹  Protocol: Clean Slate", trigger_clean_slate),
        pystray.MenuItem("🛰️  Protocol: House Party (Diagnostic)", trigger_house_party),
        pystray.MenuItem("🛡️  Protocol: Sentry Mode (Defcon)", trigger_sentry_mode),
        pystray.MenuItem("⚡  Protocol: Veronica Governor", trigger_veronica),
        pystray.Menu.SEPARATOR,
        pystray.MenuItem("🎙️  Launch Desktop Assistant", launch_desktop_assistant),
        pystray.MenuItem("👾  Launch Daemon Mode", launch_daemon_mode),
        pystray.Menu.SEPARATOR,
        pystray.MenuItem("⏸️   Pause All Tasks", pause_execution),
        pystray.MenuItem("▶️   Resume Execution", resume_execution),
        pystray.Menu.SEPARATOR,
        pystray.MenuItem("🔴  Quit J.A.R.V.I.S.", on_quit),
    )


# ── Entry point ────────────────────────────────────────────────────────────────

def main():
    # Load .env before anything touches config
    from dotenv import load_dotenv
    load_dotenv(BASE_DIR / ".env")

    print("[J.A.R.V.I.S.] Initializing cloud backend...")
    start_server()

    icon_image = create_icon_image(64)
    tray_icon = pystray.Icon(
        name="JARVIS",
        icon=icon_image,
        title=f"J.A.R.V.I.S. 2.0 — Cloud Running on :{PORT}",
        menu=build_menu(None),
    )
    tray_icon.run()


if __name__ == "__main__":
    main()
