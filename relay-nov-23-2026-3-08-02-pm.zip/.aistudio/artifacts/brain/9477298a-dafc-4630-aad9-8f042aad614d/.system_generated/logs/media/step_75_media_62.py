#!/usr/bin/env python3
"""
Quick validation script to verify all daemon modules import and initialize correctly.
"""
import sys
import time

print("=" * 80)
print("DAEMON MODULE IMPORT AND INITIALIZATION TEST")
print("=" * 80)

# Test 1: Import all modules
print("\n[1] Testing module imports...")
try:
    from core.brain import JarvisBrain
    print("  ✓ JarvisBrain")
except ImportError as e:
    print(f"  ✗ JarvisBrain: {e}")
    sys.exit(1)

try:
    from core.system_monitor import SystemMonitor
    print("  ✓ SystemMonitor")
except ImportError as e:
    print(f"  ✗ SystemMonitor: {e}")
    sys.exit(1)

try:
    from core.audio_listener import AudioListener
    print("  ✓ AudioListener")
except ImportError as e:
    print(f"  ✗ AudioListener: {e}")
    sys.exit(1)

try:
    from core.gui_operator import GuiOperator
    print("  ✓ GuiOperator")
except ImportError as e:
    print(f"  ✗ GuiOperator: {e}")
    sys.exit(1)

try:
    from core import task_executor
    print("  ✓ task_executor")
except ImportError as e:
    print(f"  ✗ task_executor: {e}")
    sys.exit(1)

# Test 2: Initialize modules
print("\n[2] Testing module initialization...")
start_time = time.time()

try:
    brain = JarvisBrain()
    print("  ✓ JarvisBrain() created")
except Exception as e:
    print(f"  ✗ JarvisBrain(): {e}")
    sys.exit(1)

try:
    monitor = SystemMonitor(check_interval=5.0)
    print("  ✓ SystemMonitor() created")
except Exception as e:
    print(f"  ✗ SystemMonitor(): {e}")
    sys.exit(1)

try:
    listener = AudioListener(brain=brain, sensitivity=0.5)
    print("  ✓ AudioListener() created")
except Exception as e:
    print(f"  ✗ AudioListener(): {e}")
    sys.exit(1)

try:
    gui = GuiOperator.get_instance()
    print("  ✓ GuiOperator.get_instance() created")
except Exception as e:
    print(f"  ✗ GuiOperator.get_instance(): {e}")
    sys.exit(1)

try:
    task_executor.clear_interrupt()
    print("  ✓ task_executor.clear_interrupt()")
except Exception as e:
    print(f"  ✗ task_executor: {e}")
    sys.exit(1)

init_time = time.time() - start_time

# Test 3: Verify parse_capabilities
print("\n[3] Testing brain.parse_capabilities()...")
try:
    capabilities = brain.parse_capabilities("open chrome")
    if isinstance(capabilities, list):
        print(f"  ✓ parse_capabilities() returns list ({len(capabilities)} items)")
    else:
        print(f"  ✓ parse_capabilities() returns: {type(capabilities)}")
except Exception as e:
    print(f"  ✗ parse_capabilities(): {e}")
    sys.exit(1)

# Test 4: Start monitoring
print("\n[4] Testing SystemMonitor background thread...")
try:
    monitor.start_monitoring()
    time.sleep(0.5)
    
    import threading
    found_monitor_thread = False
    for thread in threading.enumerate():
        if "SystemMonitorThread" in thread.name:
            found_monitor_thread = True
            print(f"  ✓ SystemMonitor running in background ({thread.name})")
            break
    
    if not found_monitor_thread:
        print("  ⚠ SystemMonitor thread not found, but monitoring may be started")
    
    monitor.stop_monitoring()
    print("  ✓ SystemMonitor stopped cleanly")
except Exception as e:
    print(f"  ✗ SystemMonitor background: {e}")
    sys.exit(1)

# Test 5: Interrupt mechanism
print("\n[5] Testing TaskExecutor interrupt mechanism...")
try:
    task_executor.clear_interrupt()
    assert not task_executor.is_interrupted(), "Should not be interrupted initially"
    
    task_executor.set_interrupt()
    assert task_executor.is_interrupted(), "Should be interrupted"
    
    task_executor.clear_interrupt()
    assert not task_executor.is_interrupted(), "Should not be interrupted after clear"
    
    print("  ✓ Interrupt mechanism fully functional")
except Exception as e:
    print(f"  ✗ Interrupt mechanism: {e}")
    sys.exit(1)

# Summary
print("\n" + "=" * 80)
print(f"INITIALIZATION TIME: {init_time:.2f}s")
if init_time < 2.0:
    print("✓ All modules initialized in < 2 seconds")
else:
    print(f"⚠ Initialization took {init_time:.2f}s (target: < 2s)")

print("\nSTATUS: All tests passed ✓")
print("=" * 80)
