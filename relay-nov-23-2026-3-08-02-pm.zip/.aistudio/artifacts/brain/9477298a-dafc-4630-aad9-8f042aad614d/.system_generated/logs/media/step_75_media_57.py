"""
Test Suite for AudioListener Module

Tests:
  1. Import verification
  2. Initialization
  3. Start/stop lifecycle
  4. Wake word detection (fallback)
  5. Configuration management
  6. Thread safety
  7. Sensitivity settings
  8. Command counting
  9. CPU usage monitoring
  10. Brain integration
"""

import unittest
import threading
import time
import logging
import sys
import os
from unittest.mock import Mock, patch, MagicMock
from pathlib import Path

# Add project root to path
PROJECT_ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(PROJECT_ROOT))

from core.audio_listener import AudioListener, AudioListenerConfig


logging.basicConfig(level=logging.DEBUG)


class TestAudioListenerImports(unittest.TestCase):
    """Test 1: Verify imports and dependencies"""
    
    def test_import_audio_listener(self):
        """Should import AudioListener successfully"""
        from core.audio_listener import AudioListener
        self.assertIsNotNone(AudioListener)
    
    def test_import_config(self):
        """Should import AudioListenerConfig successfully"""
        from core.audio_listener import AudioListenerConfig
        self.assertIsNotNone(AudioListenerConfig)
    
    def test_config_dataclass(self):
        """Should create config dataclass with proper fields"""
        config = AudioListenerConfig()
        self.assertEqual(config.enabled, True)
        self.assertEqual(config.sensitivity, 0.5)
        self.assertFalse(config.listening)
        
        # Should be convertible to dict
        config_dict = config.to_dict()
        self.assertIsInstance(config_dict, dict)
        self.assertIn("enabled", config_dict)


class TestAudioListenerInitialization(unittest.TestCase):
    """Test 2: Initialization and configuration"""
    
    def test_init_without_brain(self):
        """Should initialize without brain instance"""
        listener = AudioListener()
        self.assertIsNotNone(listener)
        self.assertIsNone(listener.brain)
        self.assertEqual(listener.sensitivity, 0.5)
    
    def test_init_with_brain(self):
        """Should initialize with brain instance"""
        mock_brain = Mock()
        listener = AudioListener(brain=mock_brain)
        self.assertEqual(listener.brain, mock_brain)
    
    def test_init_with_sensitivity(self):
        """Should respect custom sensitivity"""
        listener = AudioListener(sensitivity=0.8)
        self.assertEqual(listener.sensitivity, 0.8)
    
    def test_sensitivity_clamping(self):
        """Should clamp sensitivity to 0.0-1.0 range"""
        listener_low = AudioListener(sensitivity=-0.5)
        self.assertEqual(listener_low.sensitivity, 0.0)
        
        listener_high = AudioListener(sensitivity=1.5)
        self.assertEqual(listener_high.sensitivity, 1.0)
    
    def test_init_porcupine_disabled(self):
        """Should respect enable_porcupine=False"""
        listener = AudioListener(enable_porcupine=False)
        self.assertFalse(listener.enable_porcupine)
        self.assertIsNone(listener._porcupine_handle)


class TestAudioListenerLifecycle(unittest.TestCase):
    """Test 3: Start/stop lifecycle"""
    
    def test_start_listening(self):
        """Should start listening without errors"""
        listener = AudioListener()
        listener.start_listening()
        time.sleep(0.2)
        
        self.assertTrue(listener._running)
        listener.stop_listening()
    
    def test_stop_listening(self):
        """Should stop listening gracefully"""
        listener = AudioListener()
        listener.start_listening()
        time.sleep(0.1)
        listener.stop_listening()
        time.sleep(0.1)
        
        self.assertFalse(listener._running)
    
    def test_double_start(self):
        """Should handle double start gracefully"""
        listener = AudioListener()
        listener.start_listening()
        listener.start_listening()  # Should not cause error
        time.sleep(0.1)
        
        self.assertTrue(listener._running)
        listener.stop_listening()
    
    def test_double_stop(self):
        """Should handle double stop gracefully"""
        listener = AudioListener()
        listener.start_listening()
        listener.stop_listening()
        listener.stop_listening()  # Should not cause error
        
        self.assertFalse(listener._running)


class TestWakeWordDetection(unittest.TestCase):
    """Test 4: Wake word detection"""
    
    def test_detect_wake_word_jarvis(self):
        """Should detect 'jarvis' wake word"""
        listener = AudioListener()
        detected = listener._detect_wake_word("jarvis")
        self.assertTrue(detected)
    
    def test_detect_wake_word_hey_jarvis(self):
        """Should detect 'hey jarvis' wake word"""
        listener = AudioListener()
        detected = listener._detect_wake_word("hey jarvis")
        self.assertTrue(detected)
    
    def test_detect_wake_word_case_insensitive(self):
        """Should detect wake words case-insensitively"""
        listener = AudioListener()
        detected1 = listener._detect_wake_word("JARVIS")
        detected2 = listener._detect_wake_word("HEY JARVIS")
        detected3 = listener._detect_wake_word("Hey Jarvis Play Music")
        
        self.assertTrue(detected1)
        self.assertTrue(detected2)
        self.assertTrue(detected3)
    
    def test_no_wake_word(self):
        """Should not detect non-wake words"""
        listener = AudioListener()
        detected = listener._detect_wake_word("hello world")
        self.assertFalse(detected)
    
    def test_fallback_detection(self):
        """Should use fallback detection when Porcupine unavailable"""
        listener = AudioListener(enable_porcupine=False)
        detected = listener._detect_wake_word_fallback("hey jarvis play music")
        self.assertTrue(detected)


class TestConfigurationManagement(unittest.TestCase):
    """Test 5: Configuration state management"""
    
    def test_get_config(self):
        """Should return valid config"""
        listener = AudioListener(sensitivity=0.7)
        config = listener.get_config()
        
        self.assertIsInstance(config, AudioListenerConfig)
        self.assertEqual(config.sensitivity, 0.7)
    
    def test_set_sensitivity(self):
        """Should update sensitivity"""
        listener = AudioListener(sensitivity=0.5)
        listener.set_sensitivity(0.8)
        
        self.assertEqual(listener.sensitivity, 0.8)
    
    def test_get_command_count(self):
        """Should track command count"""
        listener = AudioListener()
        count = listener.get_command_count()
        
        self.assertEqual(count, 0)
        self.assertIsInstance(count, int)
    
    def test_get_last_command(self):
        """Should track last command"""
        listener = AudioListener()
        last = listener.get_last_command()
        
        self.assertIsNone(last)


class TestThreadSafety(unittest.TestCase):
    """Test 6: Thread safety"""
    
    def test_concurrent_state_access(self):
        """Should handle concurrent state access safely"""
        listener = AudioListener()
        errors = []
        
        def access_state():
            try:
                for _ in range(100):
                    config = listener.get_config()
                    count = listener.get_command_count()
                    listener.set_sensitivity(0.7)
            except Exception as e:
                errors.append(str(e))
        
        threads = [threading.Thread(target=access_state) for _ in range(5)]
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=5)
        
        self.assertEqual(len(errors), 0, f"Thread safety errors: {errors}")
    
    def test_listening_flag_thread_safe(self):
        """Should safely manage listening flag across threads"""
        listener = AudioListener()
        
        def check_state():
            for _ in range(50):
                _ = listener.is_listening()
        
        listener.start_listening()
        threads = [threading.Thread(target=check_state) for _ in range(3)]
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=5)
        listener.stop_listening()


class TestSensitivitySettings(unittest.TestCase):
    """Test 7: Sensitivity configuration"""
    
    def test_sensitivity_range(self):
        """Should accept sensitivity 0.0-1.0"""
        for value in [0.0, 0.25, 0.5, 0.75, 1.0]:
            listener = AudioListener(sensitivity=value)
            self.assertEqual(listener.sensitivity, value)
    
    def test_update_sensitivity(self):
        """Should allow updating sensitivity after init"""
        listener = AudioListener(sensitivity=0.5)
        listener.set_sensitivity(0.3)
        self.assertEqual(listener.sensitivity, 0.3)
        
        listener.set_sensitivity(0.9)
        self.assertEqual(listener.sensitivity, 0.9)


class TestCommandCounting(unittest.TestCase):
    """Test 8: Command counting and tracking"""
    
    def test_command_count_increments(self):
        """Should track command count"""
        listener = AudioListener()
        initial = listener.get_command_count()
        
        # Simulate internal command tracking
        with listener._lock:
            listener._command_count += 1
        
        updated = listener.get_command_count()
        self.assertEqual(updated, initial + 1)
    
    def test_last_command_tracking(self):
        """Should track last command"""
        listener = AudioListener()
        
        # Simulate command tracking
        with listener._lock:
            listener._last_command = "test command"
        
        last = listener.get_last_command()
        self.assertEqual(last, "test command")


class TestCPUUsageMonitoring(unittest.TestCase):
    """Test 9: Low-power idle state"""
    
    def test_idle_cpu_usage(self):
        """Should have minimal CPU usage when idle"""
        # This test is informational; actual CPU measurement requires psutil
        listener = AudioListener()
        
        # Just verify the listener doesn't error during idle
        config = listener.get_config()
        self.assertEqual(config.status, "idle")
    
    def test_listening_state_transitions(self):
        """Should properly track listening state"""
        listener = AudioListener()
        
        # Initially not listening
        self.assertFalse(listener.is_listening())
        
        # Simulate listening
        with listener._lock:
            listener._listening = True
        
        self.assertTrue(listener.is_listening())
        
        with listener._lock:
            listener._listening = False
        
        self.assertFalse(listener.is_listening())


class TestBrainIntegration(unittest.TestCase):
    """Test 10: Integration with JarvisBrain"""
    
    def test_brain_integration_optional(self):
        """Should work without brain instance"""
        listener = AudioListener()
        config = listener.get_config()
        self.assertIsNotNone(config)
    
    def test_with_mock_brain(self):
        """Should accept brain instance"""
        mock_brain = Mock()
        mock_brain.parse_capabilities = Mock(return_value=[])
        mock_brain.ask = Mock(return_value="Test response")
        
        listener = AudioListener(brain=mock_brain)
        self.assertEqual(listener.brain, mock_brain)
    
    @patch('core.audio_listener.listen_mic')
    @patch('core.audio_listener.speak')
    def test_command_processing_with_brain(self, mock_speak, mock_listen):
        """Should process commands through brain"""
        mock_brain = Mock()
        mock_brain.parse_capabilities = Mock(return_value=[])
        mock_brain.ask = Mock(return_value="Command executed")
        
        listener = AudioListener(brain=mock_brain)
        
        # Simulate command processing
        listener._process_command("test command")
        
        # Verify brain was called
        mock_brain.ask.assert_called()


class TestErrorHandling(unittest.TestCase):
    """Test error handling and graceful degradation"""
    
    def test_missing_porcupine_key(self):
        """Should gracefully handle missing Porcupine key"""
        with patch.dict(os.environ, {"PORCUPINE_ACCESS_KEY": ""}):
            listener = AudioListener(enable_porcupine=True, porcupine_access_key=None)
            self.assertIsNone(listener._porcupine_handle)
    
    def test_porcupine_import_error(self):
        """Should gracefully handle missing pvporcupine package"""
        with patch('core.audio_listener.pvporcupine', None):
            listener = AudioListener(enable_porcupine=True, porcupine_access_key="dummy")
            # Should not crash, fallback to string matching
            self.assertIsNone(listener._porcupine_handle)
    
    def test_cleanup_on_deletion(self):
        """Should cleanup resources on deletion"""
        listener = AudioListener()
        listener.start_listening()
        time.sleep(0.1)
        
        # Explicit cleanup
        listener.stop_listening()
        
        # Should not error on cleanup
        del listener


class TestLogging(unittest.TestCase):
    """Test logging functionality"""
    
    def test_logging_configuration(self):
        """Should have proper logging setup"""
        listener = AudioListener()
        self.assertIsNotNone(listener)
        # Logging is configured at module level


class TestConfigAsDict(unittest.TestCase):
    """Test AudioListenerConfig serialization"""
    
    def test_config_to_dict(self):
        """Should convert config to dict"""
        config = AudioListenerConfig(
            enabled=True,
            listening=False,
            sensitivity=0.6,
            commands_processed=5,
            last_command="test"
        )
        
        config_dict = config.to_dict()
        self.assertIsInstance(config_dict, dict)
        self.assertEqual(config_dict["enabled"], True)
        self.assertEqual(config_dict["sensitivity"], 0.6)
        self.assertEqual(config_dict["commands_processed"], 5)
    
    def test_config_serializable(self):
        """Config should be JSON serializable"""
        import json
        
        config = AudioListenerConfig(
            enabled=True,
            sensitivity=0.7,
            commands_processed=3
        )
        
        # Should be JSON serializable
        json_str = json.dumps(config.to_dict())
        self.assertIsInstance(json_str, str)
        
        # Should deserialize correctly
        loaded = json.loads(json_str)
        self.assertEqual(loaded["sensitivity"], 0.7)


class TestContextManager(unittest.TestCase):
    """Test resource management"""
    
    def test_cleanup_on_context_exit(self):
        """Should cleanup on exception or context exit"""
        listener = AudioListener()
        listener.start_listening()
        self.assertTrue(listener._running)
        
        listener.stop_listening()
        self.assertFalse(listener._running)


def run_tests():
    """Run all tests with detailed output"""
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()
    
    # Add all test classes
    suite.addTests(loader.loadTestsFromTestCase(TestAudioListenerImports))
    suite.addTests(loader.loadTestsFromTestCase(TestAudioListenerInitialization))
    suite.addTests(loader.loadTestsFromTestCase(TestAudioListenerLifecycle))
    suite.addTests(loader.loadTestsFromTestCase(TestWakeWordDetection))
    suite.addTests(loader.loadTestsFromTestCase(TestConfigurationManagement))
    suite.addTests(loader.loadTestsFromTestCase(TestThreadSafety))
    suite.addTests(loader.loadTestsFromTestCase(TestSensitivitySettings))
    suite.addTests(loader.loadTestsFromTestCase(TestCommandCounting))
    suite.addTests(loader.loadTestsFromTestCase(TestCPUUsageMonitoring))
    suite.addTests(loader.loadTestsFromTestCase(TestBrainIntegration))
    suite.addTests(loader.loadTestsFromTestCase(TestErrorHandling))
    suite.addTests(loader.loadTestsFromTestCase(TestLogging))
    suite.addTests(loader.loadTestsFromTestCase(TestConfigAsDict))
    suite.addTests(loader.loadTestsFromTestCase(TestContextManager))
    
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    return result.wasSuccessful()


if __name__ == "__main__":
    success = run_tests()
    sys.exit(0 if success else 1)
