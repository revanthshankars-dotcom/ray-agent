"""
Test Suite for Movie-Accurate J.A.R.V.I.S. Protocols and Sound Effects

Verifies:
1. HUD Sound Effects Synthesizer (Zero-dependency in-memory WAV math).
2. Protocol Clean Slate (Safelist compliance, memory purge, temp clean).
3. House Party Protocol (Diagnostic telemetry across battery, CPU, RAM, disk).
4. Sentry Mode / Defcon (Perimeter process anomaly scan).
5. Protocol Veronica (Local governor & cloud delegation).
6. Capability Registry & Brain parsing integration.
"""

import os
import sys
import unittest
from pathlib import Path

# Add project root to path
PROJECT_ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(PROJECT_ROOT))

from core.sound_effects import SoundSynthesizer, play_hud_sound
from core.protocols import ProtocolEngine, execute_protocol
from core.capabilities import CapabilityRegistry, CapabilityStatus
from core.brain import JarvisBrain


class TestSoundEffectsSynthesizer(unittest.TestCase):
    """Test mathematically synthesized HUD sound effects."""

    def setUp(self):
        self.synth = SoundSynthesizer.get_instance()

    def test_synthesizer_singleton(self):
        s2 = SoundSynthesizer.get_instance()
        self.assertIs(self.synth, s2)

    def test_wake_chime_generation(self):
        # Should execute without throwing exceptions
        self.synth.play_wake_chime()

    def test_affirmative_generation(self):
        self.synth.play_affirmative()

    def test_processing_blip_generation(self):
        self.synth.play_processing_blip()

    def test_alert_klaxon_generation(self):
        self.synth.play_alert_klaxon()

    def test_protocol_engaged_generation(self):
        self.synth.play_protocol_engaged()

    def test_clean_slate_sound_generation(self):
        self.synth.play_clean_slate()

    def test_convenience_play_hud_sound(self):
        for sound in ["wake", "affirmative", "blip", "alert", "protocol", "clean_slate"]:
            play_hud_sound(sound)


class TestProtocolEngine(unittest.TestCase):
    """Test movie protocols execution."""

    def setUp(self):
        self.engine = ProtocolEngine.get_instance()

    def test_protocol_clean_slate(self):
        res = self.engine.protocol_clean_slate()
        self.assertTrue(res["success"])
        self.assertEqual(res["protocol"], "Protocol Clean Slate")
        self.assertIn("speech_response", res)
        self.assertIn("memory_freed_mb", res)
        self.assertIn("closed_processes", res)
        # Verify protected processes like python.exe were NOT terminated
        self.assertNotIn("python.exe", [p.lower() for p in res["closed_processes"]])

    def test_protocol_house_party(self):
        res = self.engine.protocol_house_party()
        self.assertTrue(res["success"])
        self.assertEqual(res["protocol"], "House Party Protocol")
        self.assertIn("speech_response", res)
        self.assertIn("battery_percent", res)
        self.assertIn("cpu_percent", res)
        self.assertIn("memory_percent", res)
        self.assertGreaterEqual(res["cpu_percent"], 0)
        self.assertLessEqual(res["cpu_percent"], 100)

    def test_protocol_sentry_mode(self):
        res = self.engine.protocol_sentry_mode()
        self.assertTrue(res["success"])
        self.assertEqual(res["protocol"], "Sentry Mode")
        self.assertIn("speech_response", res)
        self.assertIn("security_status", res)
        self.assertIn(res["security_status"], ["SECURE", "ELEVATED"])

    def test_protocol_veronica(self):
        res = self.engine.protocol_veronica()
        self.assertTrue(res["success"])
        self.assertEqual(res["protocol"], "Protocol Veronica")
        self.assertIn("speech_response", res)
        self.assertEqual(res["mode"], "CLOUD_DELEGATION_PRIORITY")

    def test_execute_protocol_dispatcher(self):
        res = execute_protocol("clean_slate")
        self.assertTrue(res["success"])

        res2 = execute_protocol("house_party")
        self.assertTrue(res2["success"])

        res_unknown = execute_protocol("nonexistent_protocol_xyz")
        self.assertFalse(res_unknown["success"])


class TestCapabilitiesAndBrainIntegration(unittest.TestCase):
    """Test capabilities registration and fast-path brain parsing."""

    def setUp(self):
        self.registry = CapabilityRegistry.get_instance()
        self.brain = JarvisBrain()

    def test_execute_protocol_capability_registered(self):
        cap = self.registry.get_capability("execute_protocol")
        self.assertIsNotNone(cap)
        self.assertEqual(cap.category, "protocol")

    def test_play_hud_sound_capability_registered(self):
        cap = self.registry.get_capability("play_hud_sound")
        self.assertIsNotNone(cap)
        self.assertEqual(cap.category, "system")

    def test_execute_protocol_via_registry(self):
        res = self.registry.execute_capability("execute_protocol", {"protocol_name": "clean_slate"})
        self.assertEqual(res.status, CapabilityStatus.SUCCESS)
        self.assertTrue(res.result.get("success"))

    def test_play_hud_sound_via_registry(self):
        res = self.registry.execute_capability("play_hud_sound", {"sound_type": "affirmative"})
        self.assertEqual(res.status, CapabilityStatus.SUCCESS)

    def test_brain_parse_movie_protocols_fast_path(self):
        # Fast path test without waiting for LLM network latency
        caps = self.brain.parse_capabilities("Jarvis, execute protocol clean slate now")
        self.assertIsInstance(caps, list)
        self.assertGreater(len(caps), 0)
        self.assertEqual(caps[0]["capability_name"], "execute_protocol")
        self.assertEqual(caps[0]["input_data"]["protocol_name"], "clean_slate")

        caps_hp = self.brain.parse_capabilities("initiate house party protocol")
        self.assertEqual(caps_hp[0]["capability_name"], "execute_protocol")
        self.assertEqual(caps_hp[0]["input_data"]["protocol_name"], "house_party")

        caps_sentry = self.brain.parse_capabilities("engage sentry mode")
        self.assertEqual(caps_sentry[0]["capability_name"], "execute_protocol")
        self.assertEqual(caps_sentry[0]["input_data"]["protocol_name"], "sentry_mode")

        caps_veronica = self.brain.parse_capabilities("deploy protocol veronica")
        self.assertEqual(caps_veronica[0]["capability_name"], "execute_protocol")
        self.assertEqual(caps_veronica[0]["input_data"]["protocol_name"], "veronica")


if __name__ == "__main__":
    unittest.main()
