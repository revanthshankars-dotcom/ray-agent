#!/usr/bin/env python3
"""
Test script for verifying all 4 blocking fixes are working.
Run: python test_blocking_fixes.py  OR  pytest test_blocking_fixes.py
"""

import sys
import json
import inspect
import unittest
from pathlib import Path

# Setup path
BASE_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE_DIR))


class TestDaemonMode(unittest.TestCase):
    """Test 1: Daemon mode argparse integration."""

    def test_daemon_mode_function_exists(self):
        from main import run_daemon_mode
        self.assertTrue(callable(run_daemon_mode), "run_daemon_mode() must be callable")

    def test_argparse_available(self):
        import argparse
        self.assertIsNotNone(argparse)


class TestBrainParseCapabilities(unittest.TestCase):
    """Test 2: JarvisBrain.parse_capabilities() method."""

    def test_method_exists(self):
        from core.brain import JarvisBrain
        self.assertTrue(hasattr(JarvisBrain, 'parse_capabilities'),
                        "parse_capabilities() method must exist on JarvisBrain")

    def test_method_signature(self):
        from core.brain import JarvisBrain
        sig = inspect.signature(JarvisBrain.parse_capabilities)
        params = list(sig.parameters.keys())
        self.assertIn('self', params)
        self.assertIn('user_command', params)

    def test_fast_path_clean_slate(self):
        from core.brain import JarvisBrain
        brain = JarvisBrain.__new__(JarvisBrain)
        result = brain.parse_capabilities("initiate clean slate protocol")
        self.assertIsInstance(result, list)
        self.assertTrue(len(result) > 0)
        self.assertEqual(result[0]['capability_name'], 'execute_protocol')
        self.assertEqual(result[0]['input_data']['protocol_name'], 'clean_slate')

    def test_fast_path_screenshot(self):
        from core.brain import JarvisBrain
        brain = JarvisBrain.__new__(JarvisBrain)
        result = brain.parse_capabilities("take a screenshot")
        self.assertIsInstance(result, list)
        self.assertTrue(len(result) > 0)
        self.assertEqual(result[0]['capability_name'], 'take_screenshot')


class TestTaskExecutorInterrupt(unittest.TestCase):
    """Test 3: Emergency stop mechanism (task_executor.py)."""

    def test_imports(self):
        from core.task_executor import (
            set_interrupt, clear_interrupt, is_interrupted,
            execute_task_with_interrupt
        )
        self.assertTrue(callable(set_interrupt))
        self.assertTrue(callable(clear_interrupt))
        self.assertTrue(callable(is_interrupted))
        self.assertTrue(callable(execute_task_with_interrupt))

    def test_interrupt_cycle(self):
        from core.task_executor import set_interrupt, clear_interrupt, is_interrupted
        clear_interrupt()
        self.assertFalse(is_interrupted(), "Should start cleared")
        set_interrupt()
        self.assertTrue(is_interrupted(), "Should be set after set_interrupt()")
        clear_interrupt()
        self.assertFalse(is_interrupted(), "Should be cleared again")


class TestTrayDocumentation(unittest.TestCase):
    """Test 4: Tray system strategy documentation."""

    def setUp(self):
        self.tray_path = BASE_DIR / "tray.py"
        if self.tray_path.exists():
            with open(self.tray_path, "r", encoding="utf-8") as f:
                self.tray_content = f.read()
        else:
            self.tray_content = ""

    def test_dual_mode_documented(self):
        self.assertIn("Dual-Mode Execution Strategy", self.tray_content,
                      "Dual-Mode Execution Strategy must be documented in tray.py")

    def test_launch_daemon_mode_present(self):
        self.assertIn("launch_daemon_mode", self.tray_content,
                      "launch_daemon_mode() must be present in tray.py")

    def test_pause_resume_present(self):
        self.assertIn("pause_execution", self.tray_content,
                      "pause_execution() must be in tray.py")
        self.assertIn("resume_execution", self.tray_content,
                      "resume_execution() must be in tray.py")

    def test_task_executor_imported(self):
        self.assertIn("from core.task_executor import", self.tray_content,
                      "task_executor interrupt mechanism must be imported in tray.py")


class TestDaemonServices(unittest.TestCase):
    """Test 5: SystemMonitor & AudioListener daemon services."""

    def test_system_monitor_import(self):
        from core.system_monitor import SystemMonitor
        self.assertTrue(hasattr(SystemMonitor, 'start'), "SystemMonitor needs start()")
        self.assertTrue(hasattr(SystemMonitor, 'stop'), "SystemMonitor needs stop()")

    def test_audio_listener_import(self):
        from core.audio_listener import AudioListener
        self.assertTrue(hasattr(AudioListener, 'start'), "AudioListener needs start()")
        self.assertTrue(hasattr(AudioListener, 'stop'), "AudioListener needs stop()")


if __name__ == "__main__":
    unittest.main(verbosity=2)
