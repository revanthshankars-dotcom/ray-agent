#!/usr/bin/env python3
"""
Test suite for SystemMonitor module.
Verifies imports, monitoring lifecycle, metrics, hog detection, battery analysis, thread safety, and graceful fallbacks.
"""

import sys
import time
import threading
from datetime import datetime

def test_imports():
    """Test 1: Verify imports and module structure."""
    print("\n=== TEST 1: Imports ===")
    try:
        from core.system_monitor import (
            SystemMonitor, 
            SystemMetrics, 
            ResourceHogAlert, 
            BatteryAnalysis,
            _metrics_to_json,
            _alert_to_json
        )
        print("✓ All imports successful")
        return True
    except ImportError as e:
        print(f"✗ Import failed: {e}")
        return False


def test_monitor_start_stop():
    """Test 2: Start and stop monitoring."""
    print("\n=== TEST 2: Start/Stop Monitoring ===")
    try:
        from core.system_monitor import SystemMonitor
        
        monitor = SystemMonitor(check_interval=1.0)
        
        print("Starting monitor...")
        monitor.start_monitoring()
        time.sleep(0.5)
        
        if not monitor.running:
            print("✗ Monitor did not start")
            return False
        
        print("✓ Monitor started")
        
        print("Stopping monitor...")
        monitor.stop_monitoring()
        time.sleep(0.2)
        
        if monitor.running:
            print("✗ Monitor did not stop")
            return False
        
        print("✓ Monitor stopped")
        return True
    except Exception as e:
        print(f"✗ Test failed: {e}")
        return False


def test_get_current_metrics():
    """Test 3: Get current metrics snapshot."""
    print("\n=== TEST 3: Get Current Metrics ===")
    try:
        from core.system_monitor import SystemMonitor
        
        monitor = SystemMonitor()
        metrics = monitor.get_current_metrics()
        
        # Verify all fields are present
        required_fields = {
            'timestamp', 'cpu_percent', 'memory_percent', 'memory_used_mb',
            'memory_available_mb', 'disk_percent', 'disk_free_gb', 
            'network_sent_mb', 'network_recv_mb', 'battery_percent', 
            'battery_plugged', 'temperature_celsius', 'gpu_percent',
            'process_count', 'thread_count', 'boot_time'
        }
        
        for field in required_fields:
            if not hasattr(metrics, field):
                print(f"✗ Missing field: {field}")
                return False
        
        # Verify value ranges
        if not (0 <= metrics.cpu_percent <= 100):
            print(f"✗ CPU percent out of range: {metrics.cpu_percent}")
            return False
        
        if not (0 <= metrics.memory_percent <= 100):
            print(f"✗ Memory percent out of range: {metrics.memory_percent}")
            return False
        
        if metrics.process_count <= 0:
            print(f"✗ Process count invalid: {metrics.process_count}")
            return False
        
        print(f"✓ Metrics captured successfully")
        print(f"  CPU: {metrics.cpu_percent:.1f}%")
        print(f"  Memory: {metrics.memory_percent:.1f}%")
        print(f"  Processes: {metrics.process_count}")
        print(f"  Timestamp: {metrics.timestamp}")
        
        return True
    except Exception as e:
        print(f"✗ Test failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_resource_hog_detection():
    """Test 4: Resource hog detection."""
    print("\n=== TEST 4: Resource Hog Detection ===")
    try:
        from core.system_monitor import SystemMonitor
        
        monitor = SystemMonitor()
        hogs = monitor.analyze_resource_hogs()
        
        # Hogs should be a list
        if not isinstance(hogs, list):
            print(f"✗ analyze_resource_hogs() did not return a list")
            return False
        
        print(f"✓ Resource hog detection works")
        print(f"  Current hogs detected: {len(hogs)}")
        
        if hogs:
            for hog in hogs[:3]:  # Show first 3
                print(f"    - {hog.process_name} (PID: {hog.process_id})")
                print(f"      Resource: {hog.resource_type}, Usage: {hog.usage_percent:.1f}%")
        
        return True
    except Exception as e:
        print(f"✗ Test failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_battery_analysis():
    """Test 5: Battery analysis."""
    print("\n=== TEST 5: Battery Analysis ===")
    try:
        from core.system_monitor import SystemMonitor
        
        monitor = SystemMonitor()
        battery = monitor.get_battery_status()
        
        # Verify all fields
        required_fields = {
            'timestamp', 'current_percent', 'plugged_in', 
            'drain_rate_percent_per_hour', 'time_to_empty_hours',
            'health_status', 'recommendation'
        }
        
        for field in required_fields:
            if not hasattr(battery, field):
                print(f"✗ Missing field: {field}")
                return False
        
        print(f"✓ Battery analysis works")
        print(f"  Current: {battery.current_percent:.1f}%")
        print(f"  Plugged in: {battery.plugged_in}")
        print(f"  Health: {battery.health_status}")
        print(f"  Recommendation: {battery.recommendation}")
        
        return True
    except Exception as e:
        print(f"✗ Test failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_thread_safety():
    """Test 6: Thread-safe operations under concurrent access."""
    print("\n=== TEST 6: Thread Safety ===")
    try:
        from core.system_monitor import SystemMonitor
        
        monitor = SystemMonitor(check_interval=0.5)
        monitor.start_monitoring()
        
        errors = []
        
        def worker(worker_id):
            """Worker thread that calls monitor methods."""
            try:
                for _ in range(5):
                    metrics = monitor.get_current_metrics()
                    hogs = monitor.analyze_resource_hogs()
                    battery = monitor.get_battery_status()
                    alerts = monitor.get_alerts()
                    time.sleep(0.1)
            except Exception as e:
                errors.append(f"Worker {worker_id}: {e}")
        
        threads = [
            threading.Thread(target=worker, args=(i,))
            for i in range(3)
        ]
        
        for t in threads:
            t.start()
        
        for t in threads:
            t.join(timeout=5)
        
        monitor.stop_monitoring()
        
        if errors:
            print(f"✗ Errors during concurrent access:")
            for err in errors:
                print(f"  {err}")
            return False
        
        print(f"✓ Thread safety verified (3 concurrent workers)")
        return True
    except Exception as e:
        print(f"✗ Test failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_json_serialization():
    """Test 7: JSON serialization."""
    print("\n=== TEST 7: JSON Serialization ===")
    try:
        from core.system_monitor import (
            SystemMonitor, 
            _metrics_to_json, 
            _alert_to_json
        )
        import json
        
        monitor = SystemMonitor()
        metrics = monitor.get_current_metrics()
        
        # Convert to JSON and back
        json_str = _metrics_to_json(metrics)
        parsed = json.loads(json_str)
        
        if not isinstance(parsed, dict):
            print(f"✗ JSON not valid")
            return False
        
        # Check key fields present
        if 'cpu_percent' not in parsed or 'memory_percent' not in parsed:
            print(f"✗ Key fields missing from JSON")
            return False
        
        print(f"✓ JSON serialization works")
        print(f"  Metrics JSON size: {len(json_str)} bytes")
        
        return True
    except Exception as e:
        print(f"✗ Test failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_graceful_fallbacks():
    """Test 8: Graceful sensor fallbacks."""
    print("\n=== TEST 8: Graceful Fallbacks ===")
    try:
        from core.system_monitor import SystemMonitor
        
        monitor = SystemMonitor()
        
        # These should not raise exceptions even if sensors are unavailable
        temp = monitor._get_temperature_safe()
        gpu = monitor._get_gpu_percent_safe()
        battery_data = monitor._get_battery_safe()
        
        print(f"✓ All fallback methods handled gracefully")
        print(f"  Temperature: {temp}")
        print(f"  GPU: {gpu}")
        print(f"  Battery: {battery_data}")
        
        return True
    except Exception as e:
        print(f"✗ Test failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_cpu_overhead():
    """Test 9: CPU overhead check (should be <2% idle)."""
    print("\n=== TEST 9: CPU Overhead ===")
    try:
        from core.system_monitor import SystemMonitor
        import psutil
        
        monitor = SystemMonitor(check_interval=0.5)
        
        # Measure CPU before
        psutil.cpu_percent(interval=1)
        cpu_before = psutil.cpu_percent(interval=0.5)
        
        # Run monitor for a bit
        monitor.start_monitoring()
        time.sleep(3)
        monitor.stop_monitoring()
        
        # Measure CPU after
        cpu_after = psutil.cpu_percent(interval=0.5)
        
        print(f"✓ CPU overhead test completed")
        print(f"  CPU before: {cpu_before:.1f}%")
        print(f"  CPU after: {cpu_after:.1f}%")
        print(f"  Note: <2% overhead when idle is target")
        
        return True
    except Exception as e:
        print(f"✗ Test failed: {e}")
        return False


def test_memory_stability():
    """Test 10: Memory stability over extended monitoring."""
    print("\n=== TEST 10: Memory Stability ===")
    try:
        from core.system_monitor import SystemMonitor
        import psutil
        
        monitor = SystemMonitor(check_interval=0.5)
        monitor.start_monitoring()
        
        mem_before = psutil.Process().memory_info().rss / (1024 ** 2)
        
        # Run for 1+ minute
        for _ in range(6):
            time.sleep(10)
            metrics = monitor.get_current_metrics()
            hogs = monitor.analyze_resource_hogs()
        
        monitor.stop_monitoring()
        
        mem_after = psutil.Process().memory_info().rss / (1024 ** 2)
        mem_increase = mem_after - mem_before
        
        print(f"✓ Memory stability test completed")
        print(f"  Memory before: {mem_before:.1f} MB")
        print(f"  Memory after: {mem_after:.1f} MB")
        print(f"  Increase: {mem_increase:.1f} MB")
        
        # Should not leak more than 10 MB
        if mem_increase > 10:
            print(f"⚠ Warning: Memory increased significantly")
        
        return True
    except Exception as e:
        print(f"✗ Test failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def main():
    """Run all tests."""
    print("=" * 60)
    print("SystemMonitor Test Suite")
    print("=" * 60)
    
    tests = [
        test_imports,
        test_monitor_start_stop,
        test_get_current_metrics,
        test_resource_hog_detection,
        test_battery_analysis,
        test_thread_safety,
        test_json_serialization,
        test_graceful_fallbacks,
        test_cpu_overhead,
        test_memory_stability,
    ]
    
    results = []
    for test_func in tests:
        try:
            result = test_func()
            results.append((test_func.__name__, result))
        except Exception as e:
            print(f"\n✗ Test crashed: {e}")
            import traceback
            traceback.print_exc()
            results.append((test_func.__name__, False))
    
    # Summary
    print("\n" + "=" * 60)
    print("TEST SUMMARY")
    print("=" * 60)
    
    passed = sum(1 for _, result in results if result)
    total = len(results)
    
    for test_name, result in results:
        status = "✓ PASS" if result else "✗ FAIL"
        print(f"{status}: {test_name}")
    
    print(f"\nTotal: {passed}/{total} passed")
    
    if passed == total:
        print("\n✓ All tests passed!")
        return 0
    else:
        print(f"\n✗ {total - passed} test(s) failed")
        return 1


if __name__ == "__main__":
    sys.exit(main())
