#!/usr/bin/env python3
"""Validate Python syntax of main.py and test files."""

import py_compile
import sys

files_to_check = [
    "main.py",
    "test_integration.py",
    "test_imports_daemon.py",
]

print("=" * 60)
print("SYNTAX VALIDATION")
print("=" * 60)

all_valid = True

for filename in files_to_check:
    try:
        py_compile.compile(filename, doraise=True)
        print(f"[OK] {filename}")
    except py_compile.PyCompileError as e:
        print(f"[FAIL] {filename}: {e}")
        all_valid = False

print("=" * 60)

if all_valid:
    print("All files have valid syntax!")
    
    # Try importing main
    print("\nAttempting to import main.py...")
    try:
        import main
        print("[OK] main.py imports successfully")
        
        # Verify functions exist
        if hasattr(main, 'main'):
            print("[OK] main() function exists")
        if hasattr(main, 'run_daemon_mode'):
            print("[OK] run_daemon_mode() function exists")
            
    except Exception as e:
        print(f"[FAIL] Import error: {e}")
        import traceback
        traceback.print_exc()
else:
    print("Syntax errors found!")
    sys.exit(1)
