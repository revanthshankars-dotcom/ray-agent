"""
Test suite for capability registry.

Tests all 15 capabilities:
1. open_application
2. close_application
3. kill_process
4. adjust_volume
5. adjust_brightness
6. check_battery_status
7. check_cpu_status
8. optimize_system
9. take_screenshot
10. click_at
11. type_text
12. search_web
13. navigate_to_url
14. play_media
15. send_notification
"""

import sys
import json
from core.capabilities import (
    CapabilityRegistry,
    get_capability_registry,
    SafetyLevel,
    CapabilityStatus,
    InputSchema,
    InputValidator,
)

def print_section(title):
    """Print a formatted section header."""
    print("\n" + "=" * 70)
    print(f"  {title}")
    print("=" * 70)


def test_registry_initialization():
    """Test that registry initializes with all 15 capabilities."""
    print_section("Test 1: Registry Initialization")
    
    registry = get_capability_registry()
    all_caps = registry.list_all()
    
    print(f"✓ Registry initialized")
    print(f"✓ Total capabilities: {len(all_caps)}")
    
    # Expected capabilities
    expected = [
        "open_application",
        "close_application",
        "kill_process",
        "adjust_volume",
        "adjust_brightness",
        "check_battery_status",
        "check_cpu_status",
        "optimize_system",
        "take_screenshot",
        "click_at",
        "type_text",
        "search_web",
        "navigate_to_url",
        "play_media",
        "send_notification",
    ]
    
    assert len(all_caps) >= len(expected), f"Expected at least {len(expected)} capabilities"
    
    for cap_name in expected:
        cap = registry.get(cap_name)
        assert cap is not None, f"Missing capability: {cap_name}"
        print(f"  ✓ {cap_name}")
    
    print(f"\n✅ All {len(expected)} expected capabilities present")


def test_capability_metadata():
    """Test that all capabilities have proper metadata."""
    print_section("Test 2: Capability Metadata")
    
    registry = get_capability_registry()
    all_caps = registry.list_all()
    
    for cap in all_caps:
        assert cap.name, "Capability missing name"
        assert cap.description, "Capability missing description"
        assert cap.category, "Capability missing category"
        assert cap.safety_level in SafetyLevel, "Invalid safety level"
        assert isinstance(cap.requires_confirmation, bool), "requires_confirmation must be bool"
        print(f"  ✓ {cap.name:25} | {cap.category:15} | {cap.safety_level.value}")
    
    print(f"\n✅ All {len(all_caps)} capabilities have valid metadata")


def test_input_schemas():
    """Test that input schemas are valid."""
    print_section("Test 3: Input Schema Validation")
    
    registry = get_capability_registry()
    
    test_cases = [
        # (capability_name, valid_inputs, invalid_inputs)
        ("open_application", {"app_name": "chrome"}, {"app_name": "invalid_app"}),
        ("adjust_volume", {"level": 50}, {"level": 150}),
        ("adjust_brightness", {"level": 75}, {"level": -10}),
        ("click_at", {"x": 100, "y": 200}, {"x": -1, "y": 100}),
        ("type_text", {"text": "hello"}, {"text": "x" * 2000}),
        ("search_web", {"query": "python"}, {}),
    ]
    
    for cap_name, valid_inputs, invalid_inputs in test_cases:
        cap = registry.get(cap_name)
        
        # Test valid inputs
        valid, error = InputValidator.validate(valid_inputs, cap.input_schema)
        assert valid, f"{cap_name} validation failed: {error}"
        print(f"  ✓ {cap_name:25} accepts valid inputs")
        
        # Test invalid inputs
        if invalid_inputs:
            valid, error = InputValidator.validate(invalid_inputs, cap.input_schema)
            assert not valid, f"{cap_name} should reject invalid inputs"
            print(f"  ✓ {cap_name:25} rejects invalid inputs")
    
    print(f"\n✅ All input schemas validated correctly")


def test_capability_categories():
    """Test that capabilities are categorized properly."""
    print_section("Test 4: Capability Categories")
    
    registry = get_capability_registry()
    categories = registry.list_by_category("system")
    
    print(f"System capabilities: {len(categories)}")
    for cap in categories:
        print(f"  - {cap.name}")
    
    assert len(categories) >= 5, "Should have at least 5 system capabilities"
    
    categories = registry.list_by_category("application")
    print(f"\nApplication capabilities: {len(categories)}")
    for cap in categories:
        print(f"  - {cap.name}")
    
    categories = registry.list_by_category("gui")
    print(f"\nGUI capabilities: {len(categories)}")
    for cap in categories:
        print(f"  - {cap.name}")
    
    categories = registry.list_by_category("browser")
    print(f"\nBrowser capabilities: {len(categories)}")
    for cap in categories:
        print(f"  - {cap.name}")
    
    print(f"\n✅ All capabilities properly categorized")


def test_safe_capabilities():
    """Test executing safe capabilities."""
    print_section("Test 5: Execute Safe Capabilities")
    
    registry = get_capability_registry()
    
    # Test check_cpu_status (should always work)
    result = registry.execute("check_cpu_status", {})
    assert result.status == CapabilityStatus.SUCCESS, f"check_cpu_status failed: {result.error}"
    assert result.result is not None, "check_cpu_status should return result"
    assert "cpu_percent" in result.result, "Missing cpu_percent in result"
    print(f"  ✓ check_cpu_status executed successfully")
    print(f"    CPU: {result.result.get('cpu_percent')}%")
    print(f"    Memory: {result.result.get('memory_percent')}%")
    
    # Test check_battery_status
    result = registry.execute("check_battery_status", {})
    print(f"  ✓ check_battery_status executed")
    if result.status == CapabilityStatus.SUCCESS:
        print(f"    Battery: {result.result.get('percent')}%")
    else:
        print(f"    (Not available: {result.error})")
    
    # Test take_screenshot
    result = registry.execute("take_screenshot", {})
    assert result.status in [CapabilityStatus.SUCCESS, CapabilityStatus.ERROR]
    print(f"  ✓ take_screenshot executed (status: {result.status.value})")
    
    print(f"\n✅ Safe capabilities executed successfully")


def test_validation_errors():
    """Test that validation errors are caught."""
    print_section("Test 6: Validation Error Handling")
    
    registry = get_capability_registry()
    
    # Test missing required parameter
    result = registry.execute("adjust_volume", {})
    assert result.status == CapabilityStatus.VALIDATION_ERROR
    print(f"  ✓ Missing parameter caught: {result.error}")
    
    # Test invalid parameter value
    result = registry.execute("adjust_volume", {"level": 150})
    assert result.status == CapabilityStatus.VALIDATION_ERROR
    print(f"  ✓ Invalid value caught: {result.error}")
    
    # Test unknown capability
    result = registry.execute("unknown_capability", {})
    assert result.status == CapabilityStatus.ERROR
    print(f"  ✓ Unknown capability caught: {result.error}")
    
    print(f"\n✅ Validation errors handled correctly")


def test_confirmation_requirements():
    """Test that confirmation requirements are enforced."""
    print_section("Test 7: Confirmation Requirements")
    
    registry = get_capability_registry()
    
    # Test kill_process requires confirmation
    cap = registry.get("kill_process")
    assert cap.requires_confirmation, "kill_process should require confirmation"
    print(f"  ✓ kill_process requires confirmation")
    
    # Test optimize_system requires confirmation
    cap = registry.get("optimize_system")
    assert cap.requires_confirmation, "optimize_system should require confirmation"
    print(f"  ✓ optimize_system requires confirmation")
    
    # Test that confirmation is enforced in execution
    result = registry.execute("kill_process", {"process_identifier": "notepad.exe"})
    assert result.status == CapabilityStatus.REQUIRES_CONFIRMATION
    print(f"  ✓ Confirmation enforced: {result.error}")
    
    # Test that confirmation can be skipped
    result = registry.execute(
        "kill_process",
        {"process_identifier": "nonexistent_process_12345.exe"},
        skip_confirmation=True
    )
    # Will either error (process not found) or succeed
    assert result.status in [CapabilityStatus.SUCCESS, CapabilityStatus.ERROR]
    print(f"  ✓ skip_confirmation parameter works (status: {result.status.value})")
    
    print(f"\n✅ Confirmation requirements enforced")


def test_safety_levels():
    """Test that capabilities have appropriate safety levels."""
    print_section("Test 8: Safety Levels")
    
    registry = get_capability_registry()
    
    # Group by safety level
    safe_caps = [cap for cap in registry.list_all() if cap.safety_level == SafetyLevel.SAFE]
    moderate_caps = [cap for cap in registry.list_all() if cap.safety_level == SafetyLevel.MODERATE]
    sensitive_caps = [cap for cap in registry.list_all() if cap.safety_level == SafetyLevel.SENSITIVE]
    
    print(f"Safe capabilities: {len(safe_caps)}")
    for cap in safe_caps:
        print(f"  - {cap.name}")
    
    print(f"\nModerate capabilities: {len(moderate_caps)}")
    for cap in moderate_caps:
        print(f"  - {cap.name}")
    
    print(f"\nSensitive capabilities: {len(sensitive_caps)}")
    for cap in sensitive_caps:
        print(f"  - {cap.name}")
    
    assert len(safe_caps) > 0, "Should have safe capabilities"
    assert len(moderate_caps) > 0, "Should have moderate capabilities"
    assert len(sensitive_caps) > 0, "Should have sensitive capabilities"
    
    print(f"\n✅ All safety levels represented")


def test_registry_serialization():
    """Test that registry can be serialized to JSON."""
    print_section("Test 9: Registry Serialization")
    
    registry = get_capability_registry()
    registry_dict = registry.to_dict()
    
    assert isinstance(registry_dict, dict)
    assert len(registry_dict) >= 15
    
    # Verify JSON serializable
    json_str = json.dumps(registry_dict)
    assert len(json_str) > 0
    print(f"  ✓ Registry serialized to JSON ({len(json_str)} bytes)")
    
    # Verify structure
    for name, cap_data in registry_dict.items():
        assert "name" in cap_data
        assert "description" in cap_data
        assert "category" in cap_data
        assert "input_schema" in cap_data
        assert "safety_level" in cap_data
    
    print(f"  ✓ All capabilities have proper JSON structure")
    print(f"\n✅ Serialization works correctly")


def test_extensibility():
    """Test that new capabilities can be added."""
    print_section("Test 10: Extensibility")
    
    from core.capabilities import Capability
    
    registry = get_capability_registry()
    initial_count = len(registry.list_all())
    
    # Create a custom capability
    def custom_handler(**inputs):
        return {"success": True, "message": "Custom capability executed"}
    
    custom_cap = Capability(
        name="custom_capability",
        description="A custom test capability",
        category="test",
        input_schema={
            "param1": InputSchema(
                type="string",
                required=True,
                description="Test parameter",
            )
        },
        requires_confirmation=False,
        safety_level=SafetyLevel.SAFE,
        handler=custom_handler,
    )
    
    registry.register(custom_cap)
    
    assert len(registry.list_all()) == initial_count + 1
    assert registry.get("custom_capability") is not None
    print(f"  ✓ Custom capability registered")
    
    # Execute custom capability
    result = registry.execute("custom_capability", {"param1": "test"})
    assert result.status == CapabilityStatus.SUCCESS
    print(f"  ✓ Custom capability executed: {result.result.get('message')}")
    
    print(f"\n✅ Extensibility works correctly")


def test_execution_timing():
    """Test that execution time is tracked."""
    print_section("Test 11: Execution Timing")
    
    registry = get_capability_registry()
    
    result = registry.execute("check_cpu_status", {})
    
    assert result.execution_time_ms > 0, "Execution time should be recorded"
    print(f"  ✓ check_cpu_status execution time: {result.execution_time_ms:.2f}ms")
    
    result = registry.execute("take_screenshot", {})
    print(f"  ✓ take_screenshot execution time: {result.execution_time_ms:.2f}ms")
    
    print(f"\n✅ Execution timing tracked")


def test_handler_error_handling():
    """Test that handler errors are caught gracefully."""
    print_section("Test 12: Handler Error Handling")
    
    registry = get_capability_registry()
    
    # Test with invalid parameter that causes handler error
    result = registry.execute("navigate_to_url", {"url": "not a valid url"})
    # Should either succeed (browser opens it anyway) or return error
    print(f"  ✓ navigate_to_url handled: {result.status.value}")
    
    # Test with missing executable (should fail gracefully)
    result = registry.execute("open_application", {"app_name": "chrome"})
    # May succeed or fail depending on whether Chrome is installed
    print(f"  ✓ open_application handled: {result.status.value}")
    if result.error:
        print(f"    Error (expected): {result.error}")
    
    print(f"\n✅ Error handling works correctly")


def test_all_capabilities_callable():
    """Test that all capabilities have handlers and are callable."""
    print_section("Test 13: Callable Verification")
    
    registry = get_capability_registry()
    all_caps = registry.list_all()
    
    callable_count = 0
    for cap in all_caps:
        assert cap.handler is not None, f"{cap.name} missing handler"
        assert callable(cap.handler), f"{cap.name} handler not callable"
        callable_count += 1
        print(f"  ✓ {cap.name:30} callable")
    
    print(f"\n✅ All {callable_count} capabilities are callable")


def test_concurrent_execution():
    """Test that registry is thread-safe for concurrent execution."""
    print_section("Test 14: Thread Safety")
    
    import threading
    
    registry = get_capability_registry()
    results = []
    errors = []
    
    def execute_capability(cap_name):
        try:
            if cap_name == "check_cpu_status":
                result = registry.execute(cap_name, {})
            else:
                result = registry.execute(cap_name, {})
            results.append((cap_name, result.status))
        except Exception as e:
            errors.append((cap_name, str(e)))
    
    # Execute multiple capabilities concurrently
    threads = []
    for _ in range(3):
        t = threading.Thread(target=execute_capability, args=("check_cpu_status",))
        threads.append(t)
        t.start()
    
    for t in threads:
        t.join()
    
    assert len(errors) == 0, f"Concurrency errors: {errors}"
    assert len(results) == 3, "All threads should complete"
    print(f"  ✓ Executed check_cpu_status 3x concurrently")
    print(f"  ✓ All threads completed successfully")
    
    print(f"\n✅ Thread safety verified")


def test_capability_description_completeness():
    """Test that all capabilities have complete descriptions."""
    print_section("Test 15: Documentation Completeness")
    
    registry = get_capability_registry()
    all_caps = registry.list_all()
    
    for cap in all_caps:
        assert len(cap.description) > 10, f"{cap.name} description too short"
        
        # Check that parameters are documented
        for param_name, param_schema in cap.input_schema.items():
            assert len(param_schema.description) > 0, f"{cap.name}.{param_name} missing description"
        
        print(f"  ✓ {cap.name:30} {cap.description[:40]}...")
    
    print(f"\n✅ All capabilities properly documented")


def main():
    """Run all tests."""
    print("\n" + "=" * 70)
    print("  JARVIS CAPABILITY REGISTRY TEST SUITE")
    print("=" * 70)
    
    tests = [
        test_registry_initialization,
        test_capability_metadata,
        test_input_schemas,
        test_capability_categories,
        test_safe_capabilities,
        test_validation_errors,
        test_confirmation_requirements,
        test_safety_levels,
        test_registry_serialization,
        test_extensibility,
        test_execution_timing,
        test_handler_error_handling,
        test_all_capabilities_callable,
        test_concurrent_execution,
        test_capability_description_completeness,
    ]
    
    passed = 0
    failed = 0
    
    for test_func in tests:
        try:
            test_func()
            passed += 1
        except AssertionError as e:
            print(f"\n❌ {test_func.__name__} FAILED: {e}")
            failed += 1
        except Exception as e:
            print(f"\n❌ {test_func.__name__} ERROR: {e}")
            failed += 1
    
    # Summary
    print_section("TEST SUMMARY")
    print(f"Total Tests: {len(tests)}")
    print(f"Passed: {passed}")
    print(f"Failed: {failed}")
    
    if failed == 0:
        print("\n✅ ALL TESTS PASSED!")
        return 0
    else:
        print(f"\n❌ {failed} TEST(S) FAILED")
        return 1


if __name__ == "__main__":
    sys.exit(main())
