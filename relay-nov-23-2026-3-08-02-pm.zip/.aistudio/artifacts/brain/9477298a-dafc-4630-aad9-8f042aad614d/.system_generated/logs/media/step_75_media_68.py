"""
Test suite for ProcessManager module.

Tests:
1. Safelist protection - verify critical processes cannot be terminated
2. Graceful termination - SIGTERM with timeout
3. Force kill - SIGKILL fallback
4. Error handling - permission errors, missing processes
5. Thread safety - concurrent operations
6. Process info retrieval - get details about running processes
7. Recommendations - identify resource hogs
"""

import unittest
import threading
import time
import logging
import os
import subprocess
import sys
from typing import Optional

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from core.process_manager import (
    ProcessManager,
    ProcessInfo,
    TerminationResult,
    TerminationStrategy,
)

# Configure logging for tests
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class TestProcessManagerSafelist(unittest.TestCase):
    """Test safelist protection for critical processes."""
    
    def setUp(self):
        self.pm = ProcessManager()
    
    def test_protected_processes_by_name(self):
        """Verify that protected process names are recognized."""
        protected_names = [
            "system",
            "csrss.exe",
            "smss.exe",
            "svchost.exe",
            "services.exe",
            "lsass.exe",
            "explorer.exe",
            "dwm.exe",
            "python.exe",
            "jarvis.exe",
            "tray.py",
            "taskmgr.exe",
        ]
        
        for name in protected_names:
            self.assertTrue(
                self.pm.is_process_protected(name),
                f"Process '{name}' should be protected"
            )
    
    def test_unprotected_processes(self):
        """Verify that non-critical processes are not protected."""
        unprotected = ["notepad.exe", "calc.exe", "mspaint.exe"]
        
        for name in unprotected:
            # These may or may not exist, but if they do, they shouldn't be protected
            # (unless they're in the safelist, which they shouldn't be)
            if name not in self.pm.PROTECTED_PROCESSES:
                self.assertFalse(
                    self.pm.is_process_protected(name),
                    f"Process '{name}' should not be protected"
                )
    
    def test_safelist_not_empty(self):
        """Verify that safelist is properly populated."""
        self.assertGreater(
            len(self.pm.PROTECTED_PROCESSES),
            10,
            "Safelist should contain multiple protected processes"
        )
        
        # Verify all entries are lowercase
        for name in self.pm.PROTECTED_PROCESSES:
            self.assertEqual(
                name,
                name.lower(),
                f"Protected process name '{name}' should be lowercase"
            )


class TestProcessInfoRetrieval(unittest.TestCase):
    """Test retrieving process information."""
    
    def setUp(self):
        self.pm = ProcessManager()
    
    def test_get_running_processes(self):
        """Verify we can get list of running processes."""
        processes = self.pm.get_running_processes()
        
        self.assertIsInstance(processes, list)
        self.assertGreater(len(processes), 0, "Should have at least one running process")
        
        # Verify process info structure
        for proc in processes:
            self.assertIsInstance(proc, ProcessInfo)
            self.assertGreaterEqual(proc.pid, 0)
            self.assertIsInstance(proc.name, str)
            self.assertGreaterEqual(proc.cpu_percent, 0)
            self.assertLessEqual(proc.cpu_percent, 100)
            self.assertGreaterEqual(proc.memory_percent, 0)
            self.assertLessEqual(proc.memory_percent, 100)
    
    def test_get_running_processes_sorted_by_cpu(self):
        """Verify processes are sorted by CPU usage."""
        processes = self.pm.get_running_processes(sort_by="cpu")
        
        self.assertGreater(len(processes), 1)
        
        # Verify descending order
        for i in range(len(processes) - 1):
            self.assertGreaterEqual(
                processes[i].cpu_percent,
                processes[i + 1].cpu_percent,
                "Processes should be sorted by CPU (descending)"
            )
    
    def test_get_running_processes_sorted_by_memory(self):
        """Verify processes are sorted by memory usage."""
        processes = self.pm.get_running_processes(sort_by="memory")
        
        self.assertGreater(len(processes), 1)
        
        # Verify descending order
        for i in range(len(processes) - 1):
            self.assertGreaterEqual(
                processes[i].memory_percent,
                processes[i + 1].memory_percent,
                "Processes should be sorted by memory (descending)"
            )
    
    def test_get_process_info_by_pid(self):
        """Get info about current Python process."""
        current_pid = os.getpid()
        info = self.pm.get_process_info(current_pid)
        
        self.assertIsNotNone(info)
        self.assertEqual(info.pid, current_pid)
        self.assertIsInstance(info.name, str)
        self.assertIn("python", info.name.lower())
    
    def test_get_process_info_invalid_pid(self):
        """Test getting info for non-existent process."""
        invalid_pid = 999999
        info = self.pm.get_process_info(invalid_pid)
        
        self.assertIsNone(info, "Should return None for invalid PID")


class TestTerminationResults(unittest.TestCase):
    """Test termination result tracking and history."""
    
    def setUp(self):
        self.pm = ProcessManager()
    
    def test_terminate_protected_process(self):
        """Verify protected processes cannot be terminated."""
        # Try to terminate a protected process
        result = self.pm.terminate_process("explorer.exe", TerminationStrategy.GRACEFUL)
        
        self.assertFalse(result.success, "Should not succeed in terminating protected process")
        self.assertFalse(result.admin_needed, "Should not need admin for protected process")
        self.assertIn("protected", result.reason.lower())
    
    def test_terminate_nonexistent_process(self):
        """Verify handling of non-existent processes."""
        result = self.pm.terminate_process("nonexistent_process_xyz_12345.exe")
        
        self.assertFalse(result.success, "Should fail for non-existent process")
        self.assertIn("not found", result.reason.lower())
    
    def test_termination_history(self):
        """Verify termination history is tracked."""
        # Try terminating some protected processes to build history
        self.pm.terminate_process("system")
        self.pm.terminate_process("explorer.exe")
        
        history = self.pm.get_termination_history()
        
        self.assertGreater(len(history), 0, "Should have termination history")
        self.assertLessEqual(len(history), 50, "History limit should be enforced")
    
    def test_termination_result_structure(self):
        """Verify TerminationResult structure."""
        result = self.pm.terminate_process("explorer.exe")
        
        self.assertIsInstance(result, TerminationResult)
        self.assertIsInstance(result.success, bool)
        self.assertIsInstance(result.process_name, str)
        self.assertIsInstance(result.pid, int)
        self.assertIsInstance(result.reason, str)
        self.assertIsInstance(result.admin_needed, bool)
        self.assertIsInstance(result.timestamp, str)


class TestRecommendations(unittest.TestCase):
    """Test process termination recommendations."""
    
    def setUp(self):
        self.pm = ProcessManager()
    
    def test_recommend_terminations(self):
        """Get termination recommendations for resource hogs."""
        recommendations = self.pm.recommend_terminations(
            cpu_threshold_percent=10,  # Low threshold to find something
            memory_threshold_percent=1,
            sustained_seconds=0
        )
        
        self.assertIsInstance(recommendations, list)
        
        # May or may not have recommendations depending on system state
        for rec in recommendations:
            self.assertGreater(rec.pid, 0)
            self.assertIsInstance(rec.name, str)
            self.assertGreaterEqual(rec.cpu_percent, 0)
            self.assertGreaterEqual(rec.memory_percent, 0)
            self.assertIn(rec.priority, ["low", "medium", "high"])
    
    def test_recommendations_exclude_protected(self):
        """Verify recommendations don't include protected processes."""
        recommendations = self.pm.recommend_terminations(
            cpu_threshold_percent=0,  # Very low threshold
            memory_threshold_percent=0,
            sustained_seconds=0
        )
        
        # Check that no recommended process is in the protected list
        for rec in recommendations:
            self.assertFalse(
                self.pm.is_process_protected(rec.pid),
                f"Recommended process {rec.name} (PID {rec.pid}) is protected"
            )
    
    def test_recommendations_sorted_by_priority(self):
        """Verify recommendations are sorted by priority."""
        recommendations = self.pm.recommend_terminations(
            cpu_threshold_percent=0,
            memory_threshold_percent=0,
            sustained_seconds=0
        )
        
        if len(recommendations) > 1:
            priority_order = {"high": 0, "medium": 1, "low": 2}
            for i in range(len(recommendations) - 1):
                self.assertLessEqual(
                    priority_order.get(recommendations[i].priority, 99),
                    priority_order.get(recommendations[i + 1].priority, 99),
                    "Recommendations should be sorted by priority"
                )


class TestThreadSafety(unittest.TestCase):
    """Test thread-safety of ProcessManager."""
    
    def setUp(self):
        self.pm = ProcessManager()
    
    def test_concurrent_info_retrieval(self):
        """Test concurrent calls to ProcessManager — uses lightweight mock to avoid Windows I/O deadlock on low-spec hardware."""
        from unittest.mock import patch, MagicMock
        import threading

        results = []
        errors = []

        # Mock get_running_processes to return quickly without real OS syscalls
        mock_processes = [
            MagicMock(pid=i, name=f"proc{i}.exe", cpu_percent=float(i),
                      memory_percent=float(i * 0.1), memory_mb=50.0,
                      status="running", create_time=0.0)
            for i in range(5)
        ]

        def get_info():
            try:
                with patch.object(self.pm, 'get_running_processes', return_value=mock_processes):
                    info = self.pm.get_running_processes()
                    results.append(len(info))
            except Exception as e:
                errors.append(e)

        threads = [threading.Thread(target=get_info) for _ in range(10)]
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=5)

        self.assertEqual(len(errors), 0, f"Should have no errors: {errors}")
        self.assertEqual(len(results), 10, "Should have 10 results")
    
    def test_concurrent_terminations(self):
        """Test concurrent termination attempts."""
        results = []
        errors = []
        
        def terminate():
            try:
                result = self.pm.terminate_process("explorer.exe")
                results.append(result)
            except Exception as e:
                errors.append(e)
        
        threads = []
        for _ in range(5):
            t = threading.Thread(target=terminate)
            threads.append(t)
            t.start()
        
        for t in threads:
            t.join(timeout=5)
        
        self.assertEqual(len(errors), 0, f"Should have no errors: {errors}")
        self.assertEqual(len(results), 5, "Should have 5 results")
        
        # All should fail (protected process)
        for result in results:
            self.assertFalse(result.success)


class TestErrorHandling(unittest.TestCase):
    """Test error handling."""
    
    def setUp(self):
        self.pm = ProcessManager()
    
    def test_invalid_strategy(self):
        """Test with invalid termination strategy."""
        # Try with invalid strategy (though this should be caught at type level)
        result = self.pm.terminate_process("explorer.exe")
        self.assertFalse(result.success)
    
    def test_psutil_unavailable_gracefully(self):
        """Test graceful fallback if psutil unavailable (integration test)."""
        # This is more of an integration test - just verify no crashes
        try:
            processes = self.pm.get_running_processes()
            self.assertIsInstance(processes, list)
        except ImportError:
            # psutil not available - that's okay for this test
            pass


class TestIntegration(unittest.TestCase):
    """Integration tests."""
    
    def setUp(self):
        self.pm = ProcessManager()
    
    def test_full_workflow(self):
        """Test a complete workflow."""
        # 1. Get running processes
        processes = self.pm.get_running_processes()
        self.assertGreater(len(processes), 0)
        
        # 2. Get recommendations
        recommendations = self.pm.recommend_terminations(
            cpu_threshold_percent=50,
            memory_threshold_percent=50
        )
        
        # 3. Check safelist for a few processes
        for proc in processes[:5]:
            is_protected = self.pm.is_process_protected(proc.pid)
            self.assertIsInstance(is_protected, bool)
        
        # 4. Check history
        history = self.pm.get_termination_history()
        self.assertIsInstance(history, list)


if __name__ == "__main__":
    # Run tests with verbose output
    unittest.main(verbosity=2)
