# J.A.R.V.I.S. End-to-End Voice Command Test Suite

## Overview

`test_voice_commands.py` is a comprehensive test suite that validates the complete voice command flow for the J.A.R.V.I.S. autonomous assistant. It simulates real-world voice interactions without requiring microphone input by mocking the audio layer and STT engine.

## Test Coverage

### Core Command Tests (10 tests)

These tests verify that typical voice commands are correctly parsed, mapped to capabilities, executed, and produce expected results.

| Test ID | Command | Validates |
|---------|---------|-----------|
| C1 | `open Chrome` | Application launch capability |
| C2 | `close Chrome` | Application termination (with confirmation) |
| C3 | `check battery` | System status query |
| C4 | `take a screenshot` | Screenshot capture and storage |
| C5 | `search for weather` | Web search execution |
| C6 | `increase volume to 70` | Audio volume control with parameter extraction |
| C7 | `adjust brightness to 50` | Display brightness control with confirmation |
| C8 | `close resource hogs` | High-CPU process termination |
| C9 | `system status` | Full system telemetry reporting |
| C10 | `open YouTube` | URL navigation to web services |

### Error Case Tests (3 tests)

These tests verify graceful handling of edge cases and error conditions.

| Test ID | Scenario | Validates |
|---------|----------|-----------|
| E1 | Unknown command | Graceful handling of unrecognized input |
| E2 | Permission denied | Error recovery from security restrictions |
| E3 | App not found | Fallback behavior when resource unavailable |

### Concurrency and Control Tests (2 tests)

These tests verify that the system handles concurrent operations and emergency stop mechanisms correctly.

| Test ID | Scenario | Validates |
|---------|----------|-----------|
| CC1 | Concurrent command queue | Sequential processing of multiple commands |
| CC2 | Emergency stop | "Jarvis, stop" interrupts running execution |

## Voice Command Flow Architecture

Each test exercises the complete end-to-end flow:

```
1. WAKE-WORD DETECTION
   ├─ Audio stream captured (mocked as no-op in tests)
   ├─ Porcupine ML engine detects wake word (~150ms latency)
   ├─ String-matching fallback if ML disabled
   └─ Output: Boolean (detected), Latency (ms)

2. SPEECH-TO-TEXT (STT)
   ├─ Audio converted to text using:
   │  ├─ Google Cloud Speech-to-Text (primary)
   │  ├─ SpeechRecognition library (fallback)
   │  └─ Pocketsphinx (offline fallback)
   ├─ Retry logic: 3 attempts with 2s backoff
   └─ Output: Recognized text, Latency (ms)

3. CAPABILITY PARSING
   ├─ JarvisBrain.parse_capabilities(command_text)
   ├─ Maps natural language to executable capabilities
   ├─ Extracts parameters (app name, volume level, etc.)
   ├─ Returns JSON list of {capability_name, input_data}
   └─ Output: Capabilities list, Parse latency (ms)

4. EXECUTION
   ├─ For each capability:
   │  ├─ Check interrupt flag (emergency stop)
   │  ├─ Verify permission (sensitive ops require confirmation)
   │  ├─ Execute with TaskExecutor
   │  ├─ Capture result and latency
   │  └─ Log to system
   ├─ Pre/post performance assessment
   └─ Output: Results list with status/latency

5. RESULT LOGGING
   ├─ VoiceCommandFlow object captures all timing data
   ├─ Latency metrics accumulated for reporting
   └─ Output: TestResult with comprehensive metrics
```

## Test Execution and Reporting

### Running the Tests

```bash
# Interactive execution
python test_voice_commands.py

# Using batch runner (Windows)
run_voice_tests.bat

# Capture output to file
python test_voice_commands.py > test_results.txt 2>&1
```

### Console Output Example

```
================================================================================
J.A.R.V.I.S. END-TO-END VOICE COMMAND TEST SUITE
================================================================================

Running tests...

✓ [C1] Open Chrome (3/3 assertions) - 42.5ms
✓ [C2] Close Chrome (4/4 assertions) - 38.1ms
✓ [C3] Check Battery (3/3 assertions) - 35.9ms
✓ [C4] Take Screenshot (3/3 assertions) - 39.2ms
✓ [C5] Search Weather (3/3 assertions) - 36.8ms
✓ [C6] Increase Volume (4/4 assertions) - 41.3ms
✓ [C7] Adjust Brightness (4/4 assertions) - 40.5ms
✓ [C8] Close Resource Hogs (3/3 assertions) - 37.6ms
✓ [C9] System Status (3/3 assertions) - 38.2ms
✓ [C10] Open YouTube (4/4 assertions) - 42.1ms
✓ [E1] Error: Unknown Command (2/2 assertions) - 33.5ms
✓ [E2] Error: Permission Denied (2/2 assertions) - 34.9ms
✓ [E3] Error: App Not Found (2/2 assertions) - 32.1ms
✓ [CC1] Concurrent Queue (3/3 assertions) - 110.2ms
✓ [CC2] Emergency Stop (3/3 assertions) - 37.8ms

================================================================================
TEST EXECUTION SUMMARY
================================================================================

Timestamp: 2024-12-20T15:45:30.123456
Total Tests: 15
  ✓ Passed: 15
  ✗ Failed: 0
  ⊘ Skipped: 0
  ✙ Errored: 0

Execution Time: 615.23ms

--------------------------------------------------------------------------------
LATENCY METRICS
--------------------------------------------------------------------------------
  total_avg_ms: 42.35
  total_min_ms: 32.10
  total_max_ms: 110.20
  total_p95_ms: 41.80

--------------------------------------------------------------------------------
ERROR RECOVERY
--------------------------------------------------------------------------------
  Success: 3/3

================================================================================
TEST SUITE COMPLETE
================================================================================
```

### JSON Report Output

Tests generate a timestamped JSON report: `test_voice_commands_report_YYYYMMDD_HHMMSS.json`

```json
{
  "timestamp": "2024-12-20T15:45:30.123456",
  "total_tests": 15,
  "tests_passed": 15,
  "tests_failed": 0,
  "tests_skipped": 0,
  "tests_errored": 0,
  "total_execution_time_ms": 615.23,
  "latency_metrics": {
    "total_avg_ms": 42.35,
    "total_min_ms": 32.10,
    "total_max_ms": 110.20,
    "total_p95_ms": 41.80
  },
  "error_recovery_success": 3,
  "error_recovery_total": 3,
  "results": [
    {
      "test_id": "C1",
      "test_name": "Open Chrome",
      "status": "pass",
      "description": "Test opening Chrome application",
      "command_flow": {
        "command_text": "open chrome",
        "wake_word_detected": true,
        "wake_detection_latency_ms": 150.0,
        "stt_output": "open chrome",
        "stt_latency_ms": 800.0,
        "capabilities_parsed": [
          {
            "capability_name": "open_app",
            "input_data": {
              "app_name": "chrome"
            }
          }
        ],
        "parse_latency_ms": 5.2,
        "execution_results": [
          {
            "capability_name": "open_app",
            "status": "success",
            "result": "Executed open_app successfully",
            "latency_ms": 200.0
          }
        ],
        "execution_latency_ms": 200.0,
        "total_latency_ms": 1155.2
      },
      "error_message": null,
      "error_traceback": null,
      "execution_time_ms": 42.5,
      "assertions_passed": 3,
      "assertions_total": 3
    }
  ]
}
```

## Key Features

### 1. Mock Audio Engine

The `MockVoiceCommandEngine` class simulates:
- Wake-word detection (with realistic latency: 100-300ms)
- Speech-to-Text conversion (simulated latency: 500-2000ms)
- Capability parsing and execution
- Interrupt signal handling

**No microphone required**: Tests run in any environment (CI/CD, headless, locked displays, etc.)

### 2. Comprehensive Latency Measurement

Each test captures and reports:
- **Wake-detection latency**: Time to detect wake word
- **STT latency**: Time for speech recognition
- **Parse latency**: Time for NLU/capability extraction
- **Execution latency**: Time for capability execution
- **Total latency**: End-to-end wake-to-result time

Aggregated statistics: min, max, average, 95th percentile

### 3. Safety & Confirmation Handling

Tests validate that sensitive operations (close app, terminate processes, brightness change) require explicit confirmation before execution.

### 4. Error Recovery Testing

Tests verify graceful handling:
- Unknown commands → no crash, error logged
- Missing apps → fallback behavior, recovery attempted
- Permission denied → error caught, execution continues

Error recovery success rate tracked in report.

### 5. Concurrent Command Processing

Tests verify that:
- Multiple commands queued are processed sequentially (no race conditions)
- Each command gets full attention before next starts
- No command interference or resource contention

### 6. Emergency Stop Mechanism

Tests verify that:
- "Jarvis, stop" command sets global interrupt flag
- Running command is cancelled cleanly
- System state remains consistent
- Next command can start after interrupt clears

### 7. Thread Safety

All tests verify:
- No race conditions in concurrent operations
- Thread locks working correctly
- State consistency across operations

## Extending the Test Suite

### Adding a New Command Test

```python
def test_custom_command(self) -> Tuple[VoiceCommandFlow, int, int]:
    """Test custom command - verify specific behavior."""
    flow = self.engine.execute_command_flow("my custom command")
    assertions_passed = 0
    assertions_total = 3
    
    # Assert 1: Command recognized
    if flow.stt_output:
        assertions_passed += 1
    
    # Assert 2: Capability identified
    if flow.capabilities_parsed and flow.capabilities_parsed[0].get("capability_name") == "my_capability":
        assertions_passed += 1
    
    # Assert 3: Execution successful
    if flow.execution_results and flow.execution_results[0].get("status") == "success":
        assertions_passed += 1
    
    self.latency_samples["total"].append(flow.total_latency_ms)
    return flow, assertions_passed, assertions_total
```

Then add to `run_all_tests()`:

```python
tests.append(
    ("CX", "Custom Command", self.test_custom_command, "Test custom command behavior")
)
```

### Adding Mock Command Mappings

Edit `MockVoiceCommandEngine.command_map`:

```python
self.command_map["custom command"] = {
    "capabilities": [{"capability_name": "custom_capability", "input_data": {}}],
    "expected_result": "Custom result",
    "has_effect": True,
    "requires_confirmation": False,
}
```

## Integration with Real System

The test suite is designed to work alongside the real J.A.R.V.I.S. components:

1. **JarvisBrain**: Tests mock `parse_capabilities()` but can be replaced with real brain instance
2. **TaskExecutor**: Tests verify interrupt mechanism works with real executor
3. **AudioListener**: Tests bypass audio but can be integrated with real listener
4. **SystemMonitor**: Tests mock system queries but can be replaced with real monitor

To integrate with real components:

```python
from core.brain import JarvisBrain
from core.system_monitor import SystemMonitor

# Replace mock engine with real components
suite.engine.brain = JarvisBrain()
suite.engine.monitor = SystemMonitor()
```

## Performance Targets

Based on system design:

| Metric | Target | Typical |
|--------|--------|---------|
| Wake-word detection | <500ms | 150-200ms |
| STT processing | <3s | 800-1500ms |
| Capability parsing | <100ms | 5-20ms |
| Capability execution | <5s | 200-2000ms |
| **Total (wake-to-result)** | **<10s** | **2-5s** |

Tests validate these targets are met.

## Troubleshooting

### Issue: Tests timeout

**Cause**: Blocking operation in mock engine
**Solution**: Check `execute_command_flow()` timeout and mock latency values

### Issue: Assertion failures

**Cause**: Command mapping missing or incorrect capability name
**Solution**: Add missing command to `command_map` dictionary

### Issue: Report not generated

**Cause**: Test run crashed before report generation
**Solution**: Check console output for exception traceback

## Dependencies

- Python 3.8+
- Standard library only (no external dependencies)
- Can be run in any Python environment

## Future Enhancements

- [ ] Real microphone input option with noise detection
- [ ] Integration with actual JarvisBrain instance
- [ ] Multi-language command testing
- [ ] Voice command stress testing (100+ concurrent)
- [ ] Performance regression detection
- [ ] Web dashboard for report visualization
- [ ] Continuous integration (CI/CD) integration
- [ ] Audio quality metrics validation

## License

Part of the J.A.R.V.I.S. Autonomous Executor project.

---

**Last Updated**: 2024-12-20
**Test Suite Version**: 1.0
**Compatibility**: J.A.R.V.I.S. v1.0+
