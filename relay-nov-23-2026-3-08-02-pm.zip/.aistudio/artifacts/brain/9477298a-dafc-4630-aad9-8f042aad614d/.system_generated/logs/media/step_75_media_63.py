#!/usr/bin/env python
"""Test just imports without any method calls."""

import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent
sys.path.insert(0, str(PROJECT_ROOT))

print("Starting import test...")
sys.stdout.flush()

try:
    print("Importing GuiOperator...")
    sys.stdout.flush()
    from core.gui_operator import GuiOperator
    print("SUCCESS: GuiOperator imported")
    sys.stdout.flush()
except Exception as e:
    print(f"FAILED: {e}")
    import traceback
    traceback.print_exc()
    sys.stdout.flush()
    sys.exit(1)

print("Test completed successfully")
