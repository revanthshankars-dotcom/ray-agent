#!/usr/bin/env python
"""Quick verification that capabilities module works."""

import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

try:
    print("Importing capabilities module...")
    from core.capabilities import (
        get_capability_registry,
        SafetyLevel,
        CapabilityStatus,
    )
    
    print("✓ Import successful\n")
    
    # Initialize registry
    print("Initializing capability registry...")
    registry = get_capability_registry()
    
    # List all capabilities
    all_caps = registry.list_all()
    print(f"✓ Loaded {len(all_caps)} capabilities\n")
    
    # Display capabilities by category
    categories = {}
    for cap in all_caps:
        if cap.category not in categories:
            categories[cap.category] = []
        categories[cap.category].append(cap.name)
    
    print("Capabilities by category:")
    for category in sorted(categories.keys()):
        print(f"\n  {category.upper()}:")
        for cap_name in sorted(categories[category]):
            cap = registry.get(cap_name)
            safety = cap.safety_level.value
            confirm = "⚠ CONFIRM" if cap.requires_confirmation else "auto"
            print(f"    - {cap_name:30} [{safety:10}] {confirm}")
    
    print(f"\n✓ Total: {len(all_caps)} capabilities\n")
    
    # Test execution of safe capability
    print("Testing safe capability execution...")
    result = registry.execute("check_cpu_status", {})
    print(f"  Status: {result.status.value}")
    if result.result:
        print(f"  CPU: {result.result.get('cpu_percent')}%")
        print(f"  Memory: {result.result.get('memory_percent')}%")
    print(f"  Time: {result.execution_time_ms:.2f}ms")
    
    # Test validation
    print("\nTesting input validation...")
    result = registry.execute("adjust_volume", {"level": 150})
    print(f"  Invalid level (150): {result.status.value}")
    print(f"  Error: {result.error}")
    
    result = registry.execute("adjust_volume", {"level": 50})
    print(f"  Valid level (50): {result.status.value}")
    
    # Test confirmation requirement
    print("\nTesting confirmation requirement...")
    result = registry.execute("kill_process", {"process_identifier": "test.exe"})
    print(f"  Without confirmation: {result.status.value}")
    print(f"  (Expected REQUIRES_CONFIRMATION)")
    
    print("\n✅ All verifications passed!")
    sys.exit(0)

except Exception as e:
    print(f"\n❌ Error: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)
