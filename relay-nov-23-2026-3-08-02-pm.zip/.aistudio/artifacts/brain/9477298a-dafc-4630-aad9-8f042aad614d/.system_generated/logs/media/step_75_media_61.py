"""
Test suite for GuiOperator module.

Tests cover:
- Module imports and dependency checking
- Screenshot operations with fallback chain
- OCR operations with graceful degradation
- Mouse and keyboard control
- Browser session management
- Error recovery and thread safety
- Coordinate clamping for multi-monitor support
- Resource cleanup
"""

import os
import sys
import threading
import time
import unittest
from pathlib import Path

# Add project root to path
PROJECT_ROOT = Path(__file__).parent
sys.path.insert(0, str(PROJECT_ROOT))


class TestGuiOperatorImports(unittest.TestCase):
    """Test module imports and initialization."""
    
    def test_import_gui_operator(self):
        """Test that gui_operator module can be imported."""
        try:
            from core.gui_operator import GuiOperator, get_gui_operator
            self.assertIsNotNone(GuiOperator)
            self.assertIsNotNone(get_gui_operator)
        except ImportError as e:
            self.fail(f"Failed to import gui_operator: {e}")
    
    def test_import_data_structures(self):
        """Test that data structures can be imported."""
        from core.gui_operator import (
            ScreenCapture, OcrResult, BrowserSession, OperationStatus
        )
        self.assertIsNotNone(ScreenCapture)
        self.assertIsNotNone(OcrResult)
        self.assertIsNotNone(BrowserSession)
        self.assertIsNotNone(OperationStatus)
    
    def test_singleton_instance(self):
        """Test GuiOperator singleton pattern."""
        from core.gui_operator import GuiOperator
        
        instance1 = GuiOperator.get_instance()
        instance2 = GuiOperator.get_instance()
        
        self.assertIs(instance1, instance2)
    
    def test_dependency_initialization(self):
        """Test that dependencies are checked on initialization."""
        from core.gui_operator import GuiOperator
        
        operator = GuiOperator()
        
        # At least screenshot backend should be available
        self.assertIsNotNone(operator._screenshot_backend)
        # Backend should be one of: mss, pil, or placeholder
        self.assertIn(operator._screenshot_backend, ["mss", "pil", "placeholder"])


class TestScreenshot(unittest.TestCase):
    """Test screenshot operations."""
    
    def setUp(self):
        from core.gui_operator import GuiOperator
        self.operator = GuiOperator.get_instance()
    
    def test_screenshot_success_or_fallback(self):
        """Test that screenshot returns valid result with any backend."""
        result = self.operator.screenshot()
        
        self.assertIsNotNone(result)
        self.assertIn(result.status, ["success", "fallback", "error"])
        self.assertIsNotNone(result.backend)
        self.assertIn(result.backend, ["mss", "pil", "placeholder"])
    
    def test_screenshot_has_timestamp(self):
        """Test that screenshot includes timestamp."""
        result = self.operator.screenshot()
        
        if result.status in ["success", "fallback"]:
            self.assertIsNotNone(result.timestamp)
    
    def test_screenshot_has_dimensions(self):
        """Test that screenshot includes dimensions."""
        result = self.operator.screenshot()
        
        if result.status in ["success", "fallback"]:
            self.assertIsNotNone(result.dimensions)
            width, height = result.dimensions
            self.assertGreater(width, 0)
            self.assertGreater(height, 0)
    
    def test_screenshot_with_region(self):
        """Test partial screenshot with region parameter."""
        region = (0, 0, 400, 300)
        result = self.operator.screenshot(region=region)
        
        if result.status in ["success", "fallback"]:
            width, height = result.dimensions
            # Region should affect dimensions (or be close)
            self.assertGreaterEqual(width, 1)
            self.assertGreaterEqual(height, 1)


class TestOcr(unittest.TestCase):
    """Test OCR operations."""
    
    def setUp(self):
        from core.gui_operator import GuiOperator
        self.operator = GuiOperator.get_instance()
    
    def test_ocr_graceful_fallback(self):
        """Test that OCR gracefully handles missing Tesseract."""
        # Create dummy image
        try:
            from PIL import Image
            img = Image.new('RGB', (100, 100), color='white')
            result = self.operator.ocr_image(img)
            
            self.assertIsNotNone(result)
            self.assertIn(result.status, ["success", "not_available", "error"])
        except ImportError:
            self.skipTest("PIL not available")
    
    def test_ocr_result_structure(self):
        """Test that OCR result has correct structure."""
        from core.gui_operator import OcrResult
        
        try:
            from PIL import Image
            img = Image.new('RGB', (100, 100), color='white')
            result = self.operator.ocr_image(img)
            
            self.assertTrue(hasattr(result, 'status'))
            self.assertTrue(hasattr(result, 'text'))
            self.assertTrue(hasattr(result, 'regions'))
            self.assertTrue(hasattr(result, 'error'))
        except ImportError:
            self.skipTest("PIL not available")


class TestMouseKeyboard(unittest.TestCase):
    """Test mouse and keyboard operations."""
    
    def setUp(self):
        from core.gui_operator import GuiOperator
        self.operator = GuiOperator.get_instance()
    
    def test_move_mouse_returns_status(self):
        """Test move_mouse returns status dict."""
        result = self.operator.move_mouse(100, 100)
        
        self.assertIsInstance(result, dict)
        self.assertIn("status", result)
        if result["status"] == "success":
            self.assertIn("x", result)
            self.assertIn("y", result)
    
    def test_click_returns_status(self):
        """Test click returns status dict."""
        result = self.operator.click(100, 100)
        
        self.assertIsInstance(result, dict)
        self.assertIn("status", result)
    
    def test_double_click_returns_status(self):
        """Test double_click returns status dict."""
        result = self.operator.double_click(100, 100)
        
        self.assertIsInstance(result, dict)
        self.assertIn("status", result)
    
    def test_right_click_returns_status(self):
        """Test right_click returns status dict."""
        result = self.operator.right_click(100, 100)
        
        self.assertIsInstance(result, dict)
        self.assertIn("status", result)
    
    def test_scroll_returns_status(self):
        """Test scroll returns status dict."""
        result = self.operator.scroll(3)
        
        self.assertIsInstance(result, dict)
        self.assertIn("status", result)
    
    def test_drag_mouse_returns_status(self):
        """Test drag_mouse returns status dict."""
        result = self.operator.drag_mouse(100, 100, 200, 200)
        
        self.assertIsInstance(result, dict)
        self.assertIn("status", result)
    
    def test_type_text_returns_status(self):
        """Test type_text returns status dict."""
        result = self.operator.type_text("test")
        
        self.assertIsInstance(result, dict)
        self.assertIn("status", result)
    
    def test_press_key_returns_status(self):
        """Test press_key returns status dict."""
        result = self.operator.press_key("space")
        
        self.assertIsInstance(result, dict)
        self.assertIn("status", result)
    
    def test_key_combination_returns_status(self):
        """Test key_combination returns status dict."""
        result = self.operator.key_combination("alt", "tab")
        
        self.assertIsInstance(result, dict)
        self.assertIn("status", result)


class TestCoordinateClamping(unittest.TestCase):
    """Test coordinate validation and clamping for multi-monitor support."""
    
    def setUp(self):
        from core.gui_operator import GuiOperator
        self.operator = GuiOperator.get_instance()
    
    def test_clamp_coordinates_negative(self):
        """Test that negative coordinates are clamped to 0."""
        x, y = self.operator._clamp_coordinates(-10, -10)
        
        self.assertEqual(x, 0)
        self.assertEqual(y, 0)
    
    def test_clamp_coordinates_over_max(self):
        """Test that coordinates exceeding max are clamped."""
        max_x, max_y = self.operator._primary_monitor_dims
        x, y = self.operator._clamp_coordinates(max_x + 100, max_y + 100)
        
        self.assertLess(x, max_x)
        self.assertLess(y, max_y)
    
    def test_clamp_coordinates_valid(self):
        """Test that valid coordinates pass through unchanged."""
        x, y = self.operator._clamp_coordinates(100, 100)
        
        self.assertEqual(x, 100)
        self.assertEqual(y, 100)


class TestBrowserOperations(unittest.TestCase):
    """Test browser automation operations."""
    
    def setUp(self):
        from core.gui_operator import GuiOperator
        self.operator = GuiOperator.get_instance()
    
    def test_browser_open_returns_dict(self):
        """Test browser_open returns proper status dict."""
        result = self.operator.browser_open()
        
        self.assertIsInstance(result, dict)
        self.assertIn("status", result)
        
        if result["status"] == "success":
            self.assertIn("session_id", result)
    
    def test_browser_open_session_limit(self):
        """Test that browser respects MAX_BROWSER_SESSIONS."""
        # This would require opening many sessions to test
        # Just verify the limit is set
        self.assertEqual(self.operator.MAX_BROWSER_SESSIONS, 5)
    
    def test_browser_idle_timeout_configured(self):
        """Test that idle timeout is configured."""
        self.assertEqual(self.operator.BROWSER_IDLE_TIMEOUT, 30 * 60)
    
    def test_browser_operation_timeout_configured(self):
        """Test that operation timeout is configured."""
        self.assertGreaterEqual(self.operator.BROWSER_OPERATION_TIMEOUT, 10)
        self.assertLessEqual(self.operator.BROWSER_OPERATION_TIMEOUT, 30)


class TestApplicationControl(unittest.TestCase):
    """Test application control operations."""
    
    def setUp(self):
        from core.gui_operator import GuiOperator
        self.operator = GuiOperator.get_instance()
    
    def test_open_application_returns_dict(self):
        """Test open_application returns status dict."""
        # Try to open notepad (common on Windows)
        result = self.operator.open_application("notepad.exe")
        
        self.assertIsInstance(result, dict)
        self.assertIn("status", result)
    
    def test_focus_window_returns_dict(self):
        """Test focus_window returns status dict."""
        result = self.operator.focus_window("Nonexistent Window")
        
        self.assertIsInstance(result, dict)
        self.assertIn("status", result)


class TestUiElementDetection(unittest.TestCase):
    """Test UI element detection operations."""
    
    def setUp(self):
        from core.gui_operator import GuiOperator
        self.operator = GuiOperator.get_instance()
    
    def test_find_element_by_text_returns_none_or_dict(self):
        """Test find_element_by_text returns None or dict."""
        result = self.operator.find_element_by_text("nonexistent_text_xyz")
        
        self.assertTrue(result is None or isinstance(result, dict))
    
    def test_find_element_by_image_returns_none_or_dict(self):
        """Test find_element_by_image returns None or dict."""
        # Use a nonexistent template path
        result = self.operator.find_element_by_image("/nonexistent/template.png")
        
        self.assertTrue(result is None or isinstance(result, dict))


class TestThreadSafety(unittest.TestCase):
    """Test thread-safe operations."""
    
    def setUp(self):
        from core.gui_operator import GuiOperator
        self.operator = GuiOperator.get_instance()
    
    def test_concurrent_screenshots(self):
        """Test concurrent screenshot operations."""
        results = []
        
        def take_screenshot():
            result = self.operator.screenshot()
            results.append(result)
        
        threads = [threading.Thread(target=take_screenshot) for _ in range(5)]
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join()
        
        self.assertEqual(len(results), 5)
        # All results should have status
        for result in results:
            self.assertIn(result.status, ["success", "fallback", "error"])
    
    def test_concurrent_mouse_operations(self):
        """Test concurrent mouse operations."""
        results = []
        
        def move_mouse():
            result = self.operator.move_mouse(100, 100)
            results.append(result)
        
        threads = [threading.Thread(target=move_mouse) for _ in range(5)]
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join()
        
        self.assertEqual(len(results), 5)


class TestErrorRecovery(unittest.TestCase):
    """Test error recovery and graceful degradation."""
    
    def setUp(self):
        from core.gui_operator import GuiOperator
        self.operator = GuiOperator.get_instance()
    
    def test_screenshot_never_crashes(self):
        """Test that screenshot operation never crashes."""
        try:
            result = self.operator.screenshot()
            # Should always return ScreenCapture, never crash
            self.assertIsNotNone(result)
        except Exception as e:
            self.fail(f"screenshot() raised exception: {e}")
    
    def test_ocr_never_crashes(self):
        """Test that OCR operation never crashes."""
        try:
            from PIL import Image
            img = Image.new('RGB', (100, 100), color='white')
            result = self.operator.ocr_image(img)
            # Should always return OcrResult, never crash
            self.assertIsNotNone(result)
        except ImportError:
            self.skipTest("PIL not available")
        except Exception as e:
            self.fail(f"ocr_image() raised exception: {e}")
    
    def test_mouse_operations_handle_missing_deps(self):
        """Test that mouse operations handle missing deps gracefully."""
        result = self.operator.move_mouse(100, 100)
        
        # Should return dict with status, never crash
        self.assertIsInstance(result, dict)
        self.assertIn("status", result)


class TestResourceCleanup(unittest.TestCase):
    """Test resource cleanup and deallocation."""
    
    def test_cleanup_method_exists(self):
        """Test that cleanup method exists and can be called."""
        from core.gui_operator import GuiOperator
        operator = GuiOperator()
        
        try:
            operator.cleanup()
        except Exception as e:
            self.fail(f"cleanup() raised exception: {e}")
    
    def test_destructor_cleanup(self):
        """Test that destructor calls cleanup."""
        from core.gui_operator import GuiOperator
        operator = GuiOperator()
        
        try:
            del operator
        except Exception as e:
            self.fail(f"__del__() raised exception: {e}")


class TestModuleConvenienceFunctions(unittest.TestCase):
    """Test module-level convenience functions."""
    
    def test_get_gui_operator_function(self):
        """Test get_gui_operator convenience function."""
        from core.gui_operator import get_gui_operator, GuiOperator
        
        operator = get_gui_operator()
        self.assertIsInstance(operator, GuiOperator)
    
    def test_screenshot_convenience_function(self):
        """Test screenshot convenience function."""
        from core.gui_operator import screenshot
        
        result = screenshot()
        self.assertIsNotNone(result)
    
    def test_click_convenience_function(self):
        """Test click convenience function."""
        from core.gui_operator import click
        
        result = click(100, 100)
        self.assertIsInstance(result, dict)
    
    def test_move_mouse_convenience_function(self):
        """Test move_mouse convenience function."""
        from core.gui_operator import move_mouse
        
        result = move_mouse(100, 100)
        self.assertIsInstance(result, dict)
    
    def test_type_text_convenience_function(self):
        """Test type_text convenience function."""
        from core.gui_operator import type_text
        
        result = type_text("test")
        self.assertIsInstance(result, dict)
    
    def test_press_key_convenience_function(self):
        """Test press_key convenience function."""
        from core.gui_operator import press_key
        
        result = press_key("space")
        self.assertIsInstance(result, dict)


def run_tests():
    """Run all tests."""
    # Create test suite
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()
    
    # Add all test cases
    suite.addTests(loader.loadTestsFromTestCase(TestGuiOperatorImports))
    suite.addTests(loader.loadTestsFromTestCase(TestScreenshot))
    suite.addTests(loader.loadTestsFromTestCase(TestOcr))
    suite.addTests(loader.loadTestsFromTestCase(TestMouseKeyboard))
    suite.addTests(loader.loadTestsFromTestCase(TestCoordinateClamping))
    suite.addTests(loader.loadTestsFromTestCase(TestBrowserOperations))
    suite.addTests(loader.loadTestsFromTestCase(TestApplicationControl))
    suite.addTests(loader.loadTestsFromTestCase(TestUiElementDetection))
    suite.addTests(loader.loadTestsFromTestCase(TestThreadSafety))
    suite.addTests(loader.loadTestsFromTestCase(TestErrorRecovery))
    suite.addTests(loader.loadTestsFromTestCase(TestResourceCleanup))
    suite.addTests(loader.loadTestsFromTestCase(TestModuleConvenienceFunctions))
    
    # Run tests
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    return result.wasSuccessful()


if __name__ == "__main__":
    success = run_tests()
    sys.exit(0 if success else 1)
