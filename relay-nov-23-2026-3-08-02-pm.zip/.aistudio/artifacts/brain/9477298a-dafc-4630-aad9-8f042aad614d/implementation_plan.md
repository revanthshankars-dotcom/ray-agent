# J.A.R.V.I.S. Second Brain, Screen Control, Security Hardening, Offline Ollama & Universal App Connectors Plan

Upgrade J.A.R.V.I.S. into a self-contained, security-hardened personal operating assistant featuring an **Obsidian-style AI Second Brain**, live **Screen Vision & GUI Screen Control**, a **Hybrid Cloud Gemini / Offline Local Ollama** engine switch, active **Gemini 4 / 3.8 / 3.1** model routing (fixing the `404` model error), free **Google Workspace** OAuth tools, and a **Universal Free App Connector Hub** — backed by an end-to-end **Security Audit & Breach Mitigation** pass.

---

### User Review & Critical Decisions

> [!IMPORTANT]
> **Synthesized Requirements & Confirmed Choices**
> - **AI Second Brain (Obsidian-Style)**: Full markdown knowledge vault with `[[wikilinks]]`, `#tags`, backlinks, interactive knowledge graph visualization, offline local `.md` folder sync via Desktop OS Bridge, and Firestore sync when signed in.
> - **Screen Access & Screen Control**: Browser display capture (`getDisplayMedia`) + OS Bridge native screenshots for screen vision, plus guarded OS Bridge mouse/keyboard/window control behind an explicit **Screen Control Armed** switch, hotkey blocklist, and instant **Stop All** kill-switch.
> - **Security Audit & Hardening**: Addresses concrete vulnerabilities identified in our codebase audit — unauthenticated room/WS access, Windows `cmd /c` shell metacharacter injection, `pkill -f` broad matching, SSRF in custom connectors, path traversal in local vault access, confirmation TTL/room mismatch, and missing rate limits.
> - **Hybrid Engine + Active Gemini Fix**: Replaces retired `gemini-2.5-flash` with active `gemini-3.1-flash-lite` fallback alongside `gemini-4-hydrogen` / `gemini-3.8-live-extended-thinking`, plus seamless switching to offline **Local Ollama**.
> - **Free-Only Google Workspace & External Apps**: Google Workspace via free client-side OAuth + confirmation dialogs; Brave, Notion, Notebook, WhatsApp, Instagram, and any custom user app via zero-cost REST tokens, webhooks, deep-links, and OS Bridge automation.

---

### 1. Security Audit Findings & Breach / Error Prevention

Our audit of the existing server, WebSocket hub, OS Bridge script, and persistence layers uncovered specific error and breach vectors that this upgrade will eliminate:

1. **Unauthenticated Room & Bridge Command Dispatch (CRITICAL)**
   - *Risk*: HTTP routes (`/api/device/command`, `/api/protocols/run`, `/api/routines/run`, `/api/confirmations/resolve`, `/api/room/:roomId`) and WebSocket handshakes (`/ws`, `/live-jarvis`) currently accept any `roomId` without verifying room ownership or a pairing secret.
   - *Fix*: Generate a cryptographic per-room **Room Access Token** (`crypto.randomBytes(24).toString('hex')`) stored in room state and embedded in the pairing QR/URL & downloadable OS Bridge script. Require `X-Relay-Room-Token` (HTTP) and `?token=` (WebSocket) verification (with automatic token issuance on initial local room creation), enforce strict `req.roomId === body.roomId` checks on confirmation resolution, and expire pending confirmations after 5 minutes.
2. **Command & Shell Injection in Desktop OS Bridge (HIGH)**
   - *Risk*: `open_url` and `open_application` currently invoke `cmd /c start` on Windows where shell metacharacters (`&`, `|`, `^`, `%`) can inject commands, while `close_application`/`kill_process` uses `pkill -f` (substring regex matching) and does not block PID `0`/`1`. Furthermore, `DevicesView` sent `{ application }` while the bridge read `target`.
   - *Fix*: Strictly validate `open_url` via `new URL()` allowing only `https:` and `http:` (routing app deep-links like `whatsapp://` or `obsidian://` through a separate validated allowlist); eliminate `cmd /c` metacharacter interpretation via strict character allowlists (`^[a-zA-Z0-9 ._-]{1,64}$`) and `powershell -NoProfile -NonInteractive -EncodedCommand` / native `execFile` without shell interpolation; switch process termination to exact process name (`pkill -x`) or numeric PID `> 1`; unify `target || application || app_name`.
3. **SSRF & Header Injection in Custom Connectors & Ollama Proxy (HIGH)**
   - *Risk*: Allowing arbitrary webhook/REST endpoints or Ollama URLs could let crafted URLs probe cloud metadata (`169.254.169.254`, `metadata.google.internal`) or inject restricted HTTP headers.
   - *Fix*: Validate custom connector URLs against an SSRF blocklist (blocking link-local, metadata hosts, and non-HTTP(S) schemes), restrict Ollama local connections strictly to `127.0.0.1` / `localhost` or an explicit user-verified LAN host, and strip forbidden headers (`Host`, `Cookie`, `Content-Length`).
4. **Local Vault Path Traversal in Second Brain OS Bridge (HIGH)**
   - *Risk*: Reading/writing `.md` files in a local Obsidian folder could allow `../` traversal or symlink escapes outside the chosen vault directory.
   - *Fix*: Lock all local Second Brain file operations inside a user-configured `RELAY_VAULT_DIR` using `fs.realpathSync()` + strict boundary verification (`resolved.startsWith(realVaultDir + path.sep)`), enforcing `.md` extensions only.
5. **Retired Model 404 & Missing Rate Limits (MEDIUM)**
   - *Risk*: Fallback to `gemini-2.5-flash` triggers `404 NOT_FOUND` errors; unprotected AI/command endpoints lack request throttling; stack traces could leak upstream details.
   - *Fix*: Update fallback model to `'gemini-3.1-flash-lite'`, sanitize error messages before sending to the client, and add sliding-window rate limiting on `/api/ai/*`, `/api/device/command`, and `/api/confirmations/resolve`.
6. **Firestore Rules Coverage for New Collections (MEDIUM)**
   - *Fix*: Extend `firestore.rules` and `firebase-blueprint.json` with strict schema validation, `hasParentUser(userId)`, `isValidId()`, bounded list/string sizes, and `request.time` timestamp validation for Ray's new `brainNotes` and `connectors` subcollections (re-linting and deploying rules cleanly).

---

### 2. Overview & Core Features

- **Obsidian-Style AI Second Brain ("Vault")**:
  - Dedicated **Brain** workspace view featuring a split note explorer, markdown editor/preview, clickable `[[wikilinks]]`, `#tags`, automatic **Backlinks** sidebar, full-text + tag search, and an interactive **Knowledge Graph** canvas showing connected notes and clusters.
  - Works seamlessly **online** (Cloud Firestore persistence), **in-session** (in-memory/browser fallback), and **offline on disk** (bidirectional `.md` sync with Ray's local Obsidian vault folder via Desktop OS Bridge).
  - Exposes J.A.R.V.I.S. tools (`search_second_brain`, `read_brain_note`, `upsert_brain_note`, `link_brain_notes`) so Ray can ask J.A.R.V.I.S. to recall prior knowledge, summarize conversations straight into linked vault notes, or map project concepts automatically.
- **Screen Vision & Guarded Screen Control**:
  - **Screen Access (Vision)**: One-click **Share Screen** in the Assistant HUD captures Ray's display/window/tab via `getDisplayMedia` (streaming high-clarity frames to J.A.R.V.I.S. chat vision or live voice) OR captures a native OS screenshot via the Desktop OS Bridge.
  - **Screen Control (GUI Operator)**: Adds cross-platform Desktop OS Bridge actions (`screenshot_screen`, `mouse_move`, `mouse_click`, `mouse_double_click`, `scroll_screen`, `type_text`, `press_hotkey`, `focus_window`) using native OS APIs (macOS AppleScript/CoreGraphics, Windows PowerShell `user32.dll`/`SendKeys`, Linux `xdotool`).
  - **Two-Stage Safety Arming**: Screen Control is **Disarmed** by default and must be explicitly armed by Ray in the HUD; coordinate bounds are validated, dangerous system hotkeys (`Ctrl+Alt+Del`, `Cmd+Q` on Finder, terminal wipe shortcuts) are permanently blocked, sensitive GUI actions trigger confirmation prompts when Safe Guard is on, and clicking **Stop All** (or saying *"Jarvis, stop"*) immediately revokes screen sharing and halts queued GUI inputs.
- **Hybrid Engine Switch (Cloud Gemini + Offline Local Ollama)**:
  - Segmented toggle in the Assistant workspace switches between **Cloud Gemini** (`gemini-4-hydrogen` / `gemini-3.1-flash-lite` / `gemini-3.8-live-extended-thinking`) and **Local Ollama**.
  - Supports **100% Offline Local Mode** (`npm run dev` on Ray's computer talking to `http://127.0.0.1:11434`) AND **Desktop Bridge Ollama Relay** (tunneling Ollama requests over the secured room WebSocket when accessing from the hosted preview).
  - Includes live model auto-discovery, connection tester, and a built-in **Offline Setup Guide** drawer.
- **Free Google Workspace & Universal App Connectors**:
  - **Google Workspace** (free client-side OAuth via Firebase Auth, in-memory token only): Gmail, Calendar, Drive, Docs, Sheets, Tasks, and Contacts — with mandatory HUD confirmation dialogs before sending emails, modifying calendar events, editing files, or deleting data.
  - **Free External & Custom Apps**: Built-in zero-cost connectors for **Notion** (free integration token), **Brave** (OS Bridge browser/search launcher), **Notebook** (NotebookLM in Brave + Local `.md` Second Brain vault), **WhatsApp** (`wa.me` / `whatsapp://` prefilled composer), **Instagram** (Brave web/DM launcher + optional free Creator token), and a **Custom App Builder** where Ray can register *any* desktop URI/app or free webhook/REST endpoint (Discord, Slack, Telegram, `ntfy.sh`, GitHub, Home Assistant) as a live J.A.R.V.I.S. tool.

---

### 3. User Experience & Visual Design

- **Navigation & Workspace Rhythm**:
  - Top bar preserves the crisp 3-zone contract (`J.A.R.V.I.S.` wordmark · concise single-line nav links `Assistant`, `Brain`, `Apps`, `Devices`, `Routines`, `Handoff` with `whitespace-nowrap shrink-0` · `Stop All` + `Pair Device`).
  - Preserves existing light/dark theme tokens (`bg-slate-50 dark:bg-slate-950`, `bg-white dark:bg-slate-900`, `border-slate-200 dark:border-slate-800`, `#2563EB` blue primary accent), `Plus Jakarta Sans` + `DM Sans` + `JetBrains Mono` (`tabular-nums`), single-level borders, and unboxed `·`-separated metadata.
- **Safety & Transparency Controls**:
  - Persistent **Screen Access** & **Screen Control Armed** status controls directly in the Assistant HUD bar (with live preview thumbnail when sharing screen and 1-click revoke).
  - Interactive **Authorization Card** for every sensitive operation (Workspace sends/deletes, Clean Slate, Kill Process, Screen GUI clicks/keystrokes when guarded).

---

### 4. Technical Architecture & Data Strategy *(Technical Reference)*

```
┌──────────────────────────────────────────────────────────────────────────────┐
│                             RAY'S J.A.R.V.I.S. HUD                           │
│  [Assistant: Gemini | Ollama] [Brain: Vault + Graph] [Apps] [Devices] [Stop] │
│  • Screen Vision Capture (getDisplayMedia)   • In-Memory Google OAuth Token  │
└───────────────┬───────────────────────────────┬──────────────────────────────┘
                │                               │
     (Authorized Google                 (Room-Token Authenticated
       Workspace REST)                    HTTPS / SSE / WebSocket)
                ▼                               ▼
┌──────────────────────────────┐  ┌────────────────────────────────────────────┐
│  Google Workspace Services   │  │     Security-Hardened Node/Express Hub     │
│  Gmail · Calendar · Drive    │  │  • Room Access Token + Rate Limiter        │
│  Docs · Sheets · Tasks       │  │  • Gemini Engine (4-hydrogen / 3.1-lite)   │
│  People / Contacts           │  │  • Local Ollama Engine + Second Brain API  │
└──────────────────────────────┘  │  • Confirmation Gate + SSRF Filter         │
                                  └─────────────┬──────────────────────────────┘
                                                │ Authenticated Room WS (/ws)
                                                ▼
                                  ┌────────────────────────────────────────────┐
                                  │    Hardened Desktop OS Bridge (Ray's PC)   │
                                  │  • Ollama Local Tunnel (127.0.0.1:11434)   │
                                  │  • Local Obsidian .md Vault (Sandbox Root) │
                                  │  • Native Screen Capture & Armed GUI Input │
                                  │  • Brave · Notion · WhatsApp · Custom URIs │
                                  └────────────────────────────────────────────┘
```

- **Data Model & State**:
  - **BrainNote**: `id`, `title`, `slug`, `folder`, `content` (Markdown with `[[wikilinks]]`), `tags`, `links` (resolved outgoing slugs), `source` (`user` | `jarvis` | `obsidian_local`), `updatedAt`, `createdAt`.
  - **AppConnector**: `id`, `name`, `category`, `connectorType` (`notion` | `bridge_app` | `url_template` | `webhook`), `endpointOrTarget`, `method`, `description`, `headersJson`, `enabled`, `requiresConfirmation`.
  - **RoomAuthSession**: `roomId`, `roomToken` (shared via pairing link/QR and OS bridge script), `screenControlArmed` (`boolean`, defaults `false`), `veronicaMode`, `interrupted`.
  - **EngineConfig**: `provider` (`gemini` | `ollama`), `ollamaBaseUrl` (`http://127.0.0.1:11434`), `ollamaModel`, `useBridgeProxy` (`boolean`).
- **Interactive Component & State Mapping**:
  - **Brain View**: Selecting a note renders Markdown + clickable `[[wikilink]]` navigation, updates the Backlinks inspector and interactive Knowledge Graph highlight, and supports real-time create/edit/delete/sync with both Firestore and the Desktop OS Bridge `.md` vault.
  - **Assistant HUD**: Capturing a screen frame (`getDisplayMedia` or OS Bridge screenshot) attaches it directly to the active turn (or live voice context); toggling **Screen Control Armed** sends an authenticated state update allowing/blocking GUI automation tools; switching to **Local Ollama** refreshes available models and switches chat + task analysis routing seamlessly.
  - **Apps & Connectors View**: Manages Google Workspace OAuth connection, Notion free integration token, preset free launchers (Brave, NotebookLM/Local Notes, WhatsApp, Instagram), and the Custom App Connector form — validating URLs/targets and registering active connectors as callable J.A.R.V.I.S. tools.
