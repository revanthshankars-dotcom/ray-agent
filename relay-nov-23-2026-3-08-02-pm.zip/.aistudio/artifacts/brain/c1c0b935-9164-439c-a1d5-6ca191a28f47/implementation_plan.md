# Revised Implementation Plan - Multi-Provider 100% Free AI Engine Router & Fallback

## User Goal
Eliminate single dependency on OpenRouter by integrating multiple **100% Free** AI API providers into an autonomous fallback router. When one free provider hits rate limits or fails, RAY instantly switches to the next free alternative without burning user credits or stopping.

## Free Providers to Integrate
1. **Google Gemini Free Tier** (`gemini-2.5-flash`, `gemini-3.5-flash-lite`) — Generous free limits via Google AI Studio.
2. **Groq Cloud Free Tier** (`llama-3.3-70b-versatile`, `llama-3.1-8b-instant`) — Extremely fast, free developer tier.
3. **Hugging Face Free Inference API** (`mistralai/Mistral-7B-Instruct-v0.3`, `meta-llama/Meta-Llama-3-8B-Instruct`) — Free open-source inference endpoints.
4. **Local Ollama** (`deepseek-r1`, `llama3.2`) — 100% offline, zero cloud dependency.
5. **OpenRouter Free Models** (`openrouter/free`, `meta-llama/llama-3.3-70b-instruct:free`) — Community free routing tier.

## Proposed Changes

### 1. Autonomous Multi-Engine Free Fallback Router (`server/freeRouter.ts` & `server.ts`)
- Build an orchestrator that attempts requests across free providers in sequence:
  `Groq (Free) -> Hugging Face (Free) -> Gemini Direct -> OpenRouter Free -> Local Ollama`.
- Automatically catches 429 Rate Limits, timeouts, or errors, instantly failing over to the next free engine.

### 2. WhatsApp & Instagram Native Tool Connectors (`server/workspace.ts`)
- Add WhatsApp and Instagram tool support for messaging and contact lookup.

### 3. Resizable Layout Component (`src/App.tsx`)
- Ensure the top selected view container is fully resizable (`resize: vertical; overflow: auto;`) so chat space is maximized.

## Verification Plan
- Compile and lint applet (`compile_applet`, `lint_applet`).
- Verify multi-engine free failover routing.
